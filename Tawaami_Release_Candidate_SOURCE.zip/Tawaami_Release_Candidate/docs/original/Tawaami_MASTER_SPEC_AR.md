TAWAAMI — توائمي 🫂🍯 MASTER SPECIFICATION — NATIVE ANDROID DIGITAL
COMPANION Version 1.0

PURPOSE Build Tawaami as a real native Android app for a personal AI
companion and task-execution assistant. This is a product specification,
not proof that features already work. Inspect the current project first,
preserve useful work, implement in stages, and report honestly.

NON-NEGOTIABLE RULES - Native Android using Kotlin and Jetpack Compose.
Never substitute HTML, a website, PWA, or WebView. - Do not turn this
into NEXUS, a gamified learning app, or an unrelated demo. - Inspect
existing files before changes. Preserve working features and back up
before destructive changes. - No decorative buttons pretending to work.
Mark unavailable features clearly. - Never claim a feature or test is
complete unless actually implemented and verified. - No private API keys
or secrets inside the APK, source code, or client-side configuration. -
Build a real installable APK; a preview or source ZIP alone is not a
finished app. - Do not promise unlimited free AI access. Disclose
quotas, costs, and external requirements.

IDENTITY Name: Tawaami — توائمي Arabic tagline: رفيقي الروح والدرب A
personal, warm, expressive AI digital companion and practical assistant.
It must remain transparent that it is AI, not a human. Keep companion
identity, appearance, personality, voice preferences, memory, projects,
and history independent of any one model/provider.

LANGUAGES — REQUIRED Arabic (ar) is the default language with full RTL
layout. English (en) must be supported for the core interface with
correct LTR layout. Architect localization so more languages can be
added, including French, Spanish, German, Turkish, Urdu, Persian, Hindi,
Chinese, Japanese, and Korean as translations become available. Use
Android resource localization or an equivalent maintainable system.
Avoid hardcoded UI strings. Include an in-app language selector and
persist the selection across restarts. Handle mixed Arabic/English,
numbers, dates, punctuation, and accessibility labels correctly. Do not
claim a language is fully translated if only partly translated. Keep
interface language separate from the companion’s response language.
Allow choosing a response language or following the user’s message
language where supported. Voice language availability depends on device
services/provider; show real availability.

ANDROID FOUNDATION Use Kotlin, Jetpack Compose, ViewModel, repositories,
lifecycle-aware state, coroutines/Flow, Room for structured local data,
DataStore for preferences, Navigation Compose where appropriate, and
tests for critical logic. Inspect the existing toolchain before choosing
versions. Document compileSdk, targetSdk, minSdk, Java/Kotlin, AGP,
Gradle wrapper, dependencies, manifest permissions, and build commands.
Support Android 11 and 15 where the actual toolchain permits. Do not
claim build success unless a build really succeeds.

UI Modern, calm, responsive mobile UI; Arabic RTL first; dark/light
themes; accessibility; restrained animations/haptics; clear loading,
empty, error, and offline states. Core sections: Home, Chat, My Tawaami,
Projects/Tasks, Files, Memory, Knowledge/Tools, Companion Studio,
Settings/Languages, Privacy/Data. Implement meaningful screens rather
than many empty mockups.

DETAILED AVATAR / APPEARANCE STUDIO Support structured settings and
multiple saved profiles: - Name, nickname, profile image,
create/edit/duplicate/switch/delete profiles. - Face shape (oval, round,
square, heart, long), proportions, jawline, forehead, cheeks, skin
tone/undertone, freckles/beauty marks where supported. - Eye shape,
size, spacing, eyelids, eye color, heterochromia where supported;
eyebrows (shape/thickness/angle/color); glasses; gaze/blinking where
supported. - Hair color, length, style, texture
(straight/wavy/curly/braided/tied), bangs, hairline, facial hair where
relevant. - Height representation, body proportions/silhouette,
posture/poses where supported. - Clothing types/styles/colors,
casual/formal/traditional/work/seasonal outfits; shoes, hats, scarves,
jewelry, eyewear, bags/accessories; save outfit presets. - Visual
styles: 2D illustration, realistic-inspired illustration, cartoon,
anime-inspired. Advanced 3D is an extension unless a real engine is
integrated. - Avatar states: idle, listening, thinking, speaking,
waiting, executing, success, error/needs input. - Expressions: calm,
happy, curious, encouraging, concerned, etc. Add blinking, eye/head
movement, gestures, and speech-synchronized mouth animation only where
genuinely supported. Keep appearance data extensible; do not represent a
static image as a fully animated 3D avatar.

PERSONALITY / COMMUNICATION STUDIO Save configurable preferences for
warmth, humor, formality, detail/conciseness, directness, emotional
expressiveness, encouragement style, initiative, greeting style,
preferred dialect/language, voice, speaking pace where supported, and
relationship framing (companion, friend, supportive digital partner,
professional assistant). Allow user-defined boundaries and optional
configurable daily check-ins/reminders. These are interaction
preferences, not claims of human feelings. Settings must persist and
influence real prompts when AI is configured.

CHAT Implement text messaging, persistent history, create/rename/delete
conversations, timestamps, retry/error states, streaming if provider
supports it, context from user-approved memory, project-linked
conversations, file/image attachments, camera entry, optional speech,
and cancellation when supported. Keep the UI provider-neutral.

AI PROVIDERS AND SECURITY Create a provider abstraction for
OpenAI-compatible APIs, Gemini, other providers, private backend, and
local models where genuinely supported. Separate provider configuration,
model selection, UI, memory, and tool execution. Cloud secrets must be
stored server-side behind a secure backend/gateway, never embedded in
the app. Without provider/backend configuration, show a clear
not-configured state and keep local features working. Handle quotas,
invalid credentials, network failures, rate limits, and unavailable
services honestly.

VOICE Support Android speech recognition and text-to-speech where
available, Arabic where device/provider supports it, language selection,
permission explanations, start/stop listening, stop playback, spoken
answers, voice search/commands, and clear
listening/processing/speaking/error states. Do not claim real-time
two-way voice unless integrated and tested.

CAMERA / VISION / OCR Implement photo picker, camera capture using
supported Android APIs, preview/confirmation, safe file handling, and
permission-aware access. Prepare provider-neutral interfaces for
OCR/text extraction, image/document understanding, scene/object
recognition, image description/comparison, vision AI, and future video
analysis. Only return analysis from an actual local library or
configured service. Explain uncertainty; a photo alone is not proof of
another person’s motives or wrongdoing.

MEMORY / PRIVACY Separate user-approved preferences, saved facts/notes,
companion settings, conversation history, project memory, and app
settings. Let users view/add/edit/delete individual memories, disable
memory, clear selected/all history, export supported data, import
supported backups, and delete local data. Persist locally. Do not call
ordinary history “intelligent memory” unless retrieval/context use is
implemented.

PROJECTS / TASK EXECUTION Persistent projects with title, description,
dates, status, progress, notes, files/photos, related conversations, and
tasks with priorities/due dates/status/history. Support
create/edit/complete/reopen/delete and progress reports based on real
stored information. Workflow: understand request, plan steps, choose
available tools, ask confirmation for sensitive/irreversible/external
actions, execute only real available integrations, verify when possible,
report success/failure/remaining work, persist state for resumption.
Never claim to have sent/purchased/deleted/changed anything without a
real authorized tool. Prepare future construction/project-management
workflows for site photos, work logs, materials, workers, progress,
quantities, invoices, and reports. Do not invent evidence or facts.

FILES / KNOWLEDGE / SEARCH Prepare TXT, Markdown, PDF, Word, images,
source code, project files, structured data. Use Android document
picker. Implement parsing only for supported formats and explain
unsupported ones. Never upload files without user action. Prepare real
integration points for search, translation, writing/editing, coding,
calculation, analysis, and summarization. Live web search requires a
configured service and internet; never fabricate results.

ONLINE / OFFLINE Show Online, Offline, AI not configured, Service
unavailable, and In progress states distinctly. Offline, preserve local
settings, memory, conversations, projects, and supported local
functions. Never pretend cloud AI/search/vision works offline. Allow
retry after connectivity returns.

PERMISSIONS / SECURITY Request camera, microphone, notifications, and
file access only when needed, explain why, and handle denial gracefully.
Minimize data collection, protect sensitive local information, and
provide clear deletion/export controls. No embedded API secrets.

TESTING / RELEASE Inspect Gradle wrapper, dependencies, manifest,
resources/localization, Kotlin compilation, navigation, persistence
across restart, Arabic RTL/English LTR, offline/error states,
camera/audio where device available, provider failure, and APK
generation/installation. Distinguish a successful build from emulator or
physical-device testing. Never claim physical-device testing unless
performed.

ROADMAP V1: reliable native foundation, Arabic RTL and English,
navigation, companion profile, persistent local chat, settings, memory
CRUD, projects/tasks, privacy controls, installable APK. V1.1: secure
real AI provider/backend, context-aware chat, errors/quotas. V1.2:
voice, photos/camera, supported documents, configured vision. V2: richer
appearance customization, multiple profiles, expressions, voice,
reminders, tools/plugins, advanced memory, backup/sync, 3D extensions.
Roadmap features are not complete until implemented and tested.

FINAL REPORT List inspected/changed files, implemented features, tested
features and method, placeholders/future work, build result and APK path
if produced, missing SDKs/libraries/backend/API setup, limitations, and
exact installation instructions. Do not claim “complete” if important
functions are missing. Do not substitute a web preview or source ZIP for
a tested installable APK.

FINAL ACTION Inspect the current project, preserve useful work, and
implement the best reliable native Android foundation possible. If a
limitation prevents an action, explain it and continue with the next
feasible task. Never silently substitute a website or unrelated product.

## ملحق رسمي — متطلبات لا يجوز إسقاطها

### التجربة الحية والرفيقة الرقمية الشخصية
- توائمي هو رفيق رقمي شخصي دائم الإعدادات، ويمكن للمستخدم تخصيص العلاقة والأسلوب بنفسه، بما في ذلك رفيق/صديق/شريك رقمي/زوجة افتراضية للبالغين. يجب ألا يُقدَّم على أنه إنسان حقيقي.
- المطلوب تجربة تفاعلية مرئية وليست صورة ثابتة فقط: حالات استماع وتفكير وتحدث وانتظار وتنفيذ؛ تعابير وحركة عين/رأس إن توفرت؛ وتحريك الفم المتزامن مع الصوت فقط عند دمج تقنية حقيقية تدعم ذلك.
- يجب فصل صورة/أصول الأفاتار عن محرك العرض ومزود الذكاء حتى يمكن الترقية من 2D إلى 3D لاحقًا. الفيديو الحي أو الشخصية الواقعية المتحركة يحتاج محرك أفاتار وخدمة صوت/AI مناسبة؛ لا يجوز وصف صورة أو حركة تجريبية بأنها بث حي حقيقي.
- يمكن تغيير المشهد والخلفية والملابس والإضاءة والثيم من إعدادات الاستوديو أثناء الاستخدام. تغيّر المشهد أثناء محادثة صوتية مستمرة ميزة مستقبلية إلى أن يُنفّذ ويرتبط بعارض فعلي.

### قسم التعليمات الخاصة
- أضف صفحة مستقلة باسم «تعليماتي الخاصة» تتيح إدخال تعليمات وتفضيلات يكتبها المستخدم بحرية، وحفظها محليًا، وعرضها، وتعديلها، وحذفها، وتفعيلها أو تعطيلها.
- يجب أن تظل التعليمات مفصولة عن سجل المحادثة والذاكرة العادية، وألا تؤثر في ردود AI إلا إذا فعّل المستخدم ذلك وكانت طبقة AI مهيأة فعليًا.
- أضف خيارات واضحة لخصوصية هذه التعليمات: محلية فقط افتراضيًا، والتحكم في حذفها وتصديرها، وعدم رفعها إلى مزود خارجي دون علم المستخدم.

### الخصوصية والتعامل مع الهاتف
- يمكن تصميم مساعد محلي لشرح الشاشة أو إرشاد المستخدم خطوة بخطوة، وقراءة المحتوى الذي يختاره أو يشاركه مع التطبيق.
- التحكم في التطبيقات الأخرى أو قراءة شاشاتها لا يحدث تلقائيًا؛ أي استخدام لخدمة Android Accessibility يجب أن يكون اختياريًا صريحًا، مع شرح لما تستطيع الوصول إليه وما لا تستطيع، وتوفير زر تعطيل واضح. تظل الشاشات الآمنة والمحتوى المحمي وقيود النظام خارج الضمان.
- لا تَعِد بعمل غير متصل يحتاج إلى خادم. تحويل الكلام إلى نص/نص إلى كلام دون إنترنت يتوقف على توفر محرك/حزم لغة محلية؛ الفهم الذكي دون إنترنت يحتاج نموذجًا محليًا مناسبًا. تحليل الصور دون الإنترنت يحتاج مكتبة أو نموذج رؤية محليًا.

### ضمانات الجودة
- تعني «موجودة» أن الميزة موصولة بتنفيذ حقيقي، وليست زرًا تجميليًا أو وصفًا في README.
- تعني «مختبرة» أن اختبارًا محددًا نُفّذ مع توثيق طريقته ونتيجته. لا تخلط بين نجاح Gradle واختبار التشغيل على جهاز فعلي.
- قبل أي تعديل، احتفظ بنسخة من المصدر المتاح وسجّل الملفات التي تغيرت. لا تُسقط أي ميزة أصلية؛ انقلها أو وثّق سبب تعذر نقلها.
- يجب أن يذكر التقرير النهائي بوضوح: ما نُفّذ، وما اختُبر، وما لم يُختبر، وما يحتاج API/خادمًا/مكتبة/صلاحية، ومسار APK فقط إذا أنتج بالفعل.
