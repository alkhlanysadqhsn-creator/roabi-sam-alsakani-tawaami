# Tawaami Android Project — Zemith Source Bundle

هذه حزمة مصدر نصية واحدة للمشروع. كل ملف أدناه مرفق بمساره الأصلي.
أعد إنشاء نفس بنية المشروع والمسارات ثم تعامل معه كمشروع Android/Kotlin قابل للتطوير.

## Project files

## FILE: `gradle.properties`

```properties
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
```

## FILE: `settings.gradle.kts`

```kotlin
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Tawaami"
include(":app")
```

## FILE: `PROJECT_SCOPE.txt`

```text
توائمي 🫂
نسخة Android أولى: chat + memory + tasks + encyclopedia + studio + speech + camera + haptics.
```

## FILE: `build.gradle.kts`

```kotlin
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}
```

## FILE: `README_AR.md`

```markdown
# توائمي 🫂 — مشروع Android شامل وقابل للتوسعة

هذه نسخة Android فعلية من المشروع، معدّة لكي تُبنى على الهاتف بواسطة بيئة تطوير Android تدعم Gradle.

## الموجود في النسخة

- واجهة عربية RTL وشاشة رئيسية كاملة.
- محادثة محلية تعمل دون مفتاح خدمة خارجي.
- ذاكرة شخصية محلية قابلة للحفظ والحذف.
- مهام ومشاريع مع إنجاز/تراجع.
- موسوعة محلية قابلة لتوسيع المحتوى.
- استوديو الشخصية: النمط، الشعر، العينان، الصوت، أسلوب الحوار.
- شخصية/أفاتار تفاعلي مع تعابير وحركة بصرية.
- اهتزازات لمسية عند التفاعل.
- إدخال صوتي عبر SpeechRecognizer عندما يدعمه الجهاز.
- قراءة صوتية TTS للردود.
- التقاط صورة بالكاميرا وعرضها داخل التطبيق.
- انتقاء صورة من الجهاز.
- أساس جاهز لإضافة مزود ذكاء اصطناعي أو نموذج محلي لاحقاً.
- تخزين الإعدادات والذاكرة والمهام محلياً في SharedPreferences.
- لا توجد إعلانات أو مشتريات داخل المشروع.

## ملاحظة مهمة عن "المجاني"

الكود نفسه مفتوح وقابل للاستخدام والتعديل، والوظائف المحلية لا تحتاج اشتراكاً. 
أما نماذج الذكاء الاصطناعي السحابية القوية، البحث الحي، أو خدمات النسخ الصوتي الخارجية، فهي تعتمد على المزود وقد تكون لها حدود مجانية أو تكلفة خاصة بها. لذلك لم أضع مفتاح خدمة مدفوعاً داخل التطبيق.

## البناء من الهاتف

1. ثبّت بيئة Android تدعم مشاريع Gradle على الهاتف.
2. فك ضغط `Tawaami_Android_Complete.zip`.
3. افتح المجلد الذي يحتوي على `settings.gradle.kts`.
4. ثبّت/فعّل JDK 17 و Android SDK 35 إن كانت البيئة تطلب ذلك.
5. نفّذ Build/Assemble Debug.
6. ثبّت ملف APK الناتج.

هذه البنية قياسية Android/Gradle وليست مرتبطة بمحرر واحد.

## الخطوة التالية للتطوير

يمكن إضافة طبقة AI حقيقية عبر واجهة مزود قابلة للتبديل:
- OpenAI-compatible API
- مزود آخر
- خادم محلي
- نموذج محلي على الجهاز عندما تتوفر ذاكرة وقدرة كافية

ويمكن كذلك إضافة قاعدة معرفة ضخمة، مزامنة مشفّرة، نسخ احتياطي، شخصيات ثلاثية الأبعاد، أدوات تنفيذ أوامر، OCR متقدم، تحليل فيديو، وإدارة مشاريع متعددة.


## توافق أنظمة Android

- الحد الأدنى: Android 11 (API 30)
- الهدف الحالي: Android 15 (API 35)
- التطبيق مصمم ليعمل على الأجهزة من Android 11 فما فوق، مع مراعاة فروق الخصائص بين الإصدارات.
```

## FILE: `app/proguard-rules.pro`

```text
# Tawaami project - no custom rules required for the first release.
```

## FILE: `app/build.gradle.kts`

```kotlin
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.tawaami.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tawaami.app"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
```

## FILE: `gradle/wrapper/gradle-wrapper.properties`

```properties
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
```

## FILE: `app/src/main/AndroidManifest.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:allowBackup="true"
        android:label="توائمي 🫂"
        android:supportsRtl="true"
        android:theme="@style/Theme.Tawaami">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
    </application>
</manifest>
```

## FILE: `app/src/main/java/com/tawaami/app/MainActivity.kt`

```kotlin
package com.tawaami.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ChatMessage(val text: String, val mine: Boolean, val time: String)
data class TawaamiTask(val id: Long, val title: String, val done: Boolean)
data class TawaamiMemory(val id: Long, val text: String)

class TawaamiRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("tawaami_store", Context.MODE_PRIVATE)

    fun saveNickname(value: String) = prefs.edit().putString("nickname", value).apply()
    fun nickname() = prefs.getString("nickname", "صاحبي") ?: "صاحبي"

    fun saveStyle(value: String) = prefs.edit().putString("style", value).apply()
    fun style() = prefs.getString("style", "واقعي") ?: "واقعي"

    fun saveHair(value: String) = prefs.edit().putString("hair", value).apply()
    fun hair() = prefs.getString("hair", "أسود") ?: "أسود"

    fun saveEyes(value: String) = prefs.edit().putString("eyes", value).apply()
    fun eyes() = prefs.getString("eyes", "بني") ?: "بني"

    fun saveVoice(value: String) = prefs.edit().putString("voice", value).apply()
    fun voice() = prefs.getString("voice", "هادئ") ?: "هادئ"

    fun saveMemories(list: List<TawaamiMemory>) {
        prefs.edit().putString("memories", list.joinToString("\n") { it.id.toString() + "|" + it.text.replace("|", " ") }).apply()
    }
    fun memories(): List<TawaamiMemory> =
        prefs.getString("memories", "")!!.split("\n").mapNotNull {
            val p = it.split("|", limit = 2)
            if (p.size == 2) TawaamiMemory(p[0].toLongOrNull() ?: 0L, p[1]) else null
        }

    fun saveTasks(list: List<TawaamiTask>) {
        prefs.edit().putString("tasks", list.joinToString("\n") {
            "${it.id}|${it.done}|${it.title.replace("|", " ")}"
        }).apply()
    }
    fun tasks(): List<TawaamiTask> =
        prefs.getString("tasks", "")!!.split("\n").mapNotNull {
            val p = it.split("|", limit = 3)
            if (p.size == 3) TawaamiTask(p[0].toLongOrNull() ?: 0L, p[2].isNotBlank() && p[1] == "true", p[2]) else null
        }
}

class LocalAiEngine {
    fun answer(input: String, memory: List<TawaamiMemory>, tasks: List<TawaamiTask>): String {
        val q = input.trim()
        val lower = q.lowercase(Locale.getDefault())
        return when {
            q.isBlank() -> "أنا معك 🫂 اكتب لي ما تريد."
            lower.contains("مرحبا") || lower.contains("السلام") || lower.contains("اهلا") ->
                "أهلاً بك 🫂 أنا توائمي. أخبرني بما تريد أن نفعله معاً."
            lower.contains("ماذا تستطيع") || lower.contains("مميزات") ->
                "أستطيع مساعدتك في المحادثة، التخطيط، المهام، الموسوعة، الكتابة، الحساب، التنظيم، وتحويل أفكارك إلى خطوات عملية."
            lower.startsWith("تذكر ") -> {
                "تم تجهيز الرسالة للحفظ في الذاكرة. استخدم زر الحفظ من قسم الذاكرة."
            }
            lower.contains("المهام") ->
                "لديك ${tasks.count { !it.done }} مهام غير مكتملة حالياً."
            lower.contains("ذاكرة") ->
                if (memory.isEmpty()) "لا توجد ذاكرة محفوظة بعد." else "لدي ${memory.size} عناصر ذاكرة محفوظة."
            lower.contains("شكرا") || lower.contains("مشكور") ->
                "العفو 🫂 دائماً إلى جانبك في إنجاز ما نستطيع."
            else ->
                "فهمت قصدك: \"$q\".\n\nأستطيع تحويل طلبك إلى خطة أو مهمة، ويمكننا توسيع هذه النواة لاحقاً بمصدر ذكاء اصطناعي فعلي للردود المتقدمة."
        }
    }
}

class TawaamiViewModel(private val appContext: Context) : ViewModel() {
    private val repo = TawaamiRepository(appContext)
    private val engine = LocalAiEngine()

    var messages by mutableStateOf(
        listOf(ChatMessage("أهلاً بك 🫂 أنا توائمي. لنبدأ من هنا.", false, now()))
    )
        private set
    var tasks by mutableStateOf(repo.tasks())
        private set
    var memories by mutableStateOf(repo.memories())
        private set
    var nickname by mutableStateOf(repo.nickname())
        private set
    var style by mutableStateOf(repo.style())
        private set
    var hair by mutableStateOf(repo.hair())
        private set
    var eyes by mutableStateOf(repo.eyes())
        private set
    var voice by mutableStateOf(repo.voice())
        private set

    fun send(text: String) {
        if (text.isBlank()) return
        val answer = engine.answer(text, memories, tasks)
        messages = messages + ChatMessage(text, true, now()) + ChatMessage(answer, false, now())
    }

    fun addTask(title: String) {
        if (title.isBlank()) return
        val item = TawaamiTask(System.currentTimeMillis(), title.trim(), false)
        tasks = tasks + item
        repo.saveTasks(tasks)
    }

    fun toggleTask(id: Long) {
        tasks = tasks.map { if (it.id == id) it.copy(done = !it.done) else it }
        repo.saveTasks(tasks)
    }

    fun deleteTask(id: Long) {
        tasks = tasks.filterNot { it.id == id }
        repo.saveTasks(tasks)
    }

    fun addMemory(text: String) {
        if (text.isBlank()) return
        memories = memories + TawaamiMemory(System.currentTimeMillis(), text.trim())
        repo.saveMemories(memories)
    }

    fun deleteMemory(id: Long) {
        memories = memories.filterNot { it.id == id }
        repo.saveMemories(memories)
    }

    fun saveStudio(newNickname: String, newStyle: String, newHair: String, newEyes: String, newVoice: String) {
        nickname = newNickname.ifBlank { "صاحبي" }
        style = newStyle
        hair = newHair
        eyes = newEyes
        voice = newVoice
        repo.saveNickname(nickname)
        repo.saveStyle(style)
        repo.saveHair(hair)
        repo.saveEyes(eyes)
        repo.saveVoice(voice)
    }
}

private fun now(): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TawaamiApp() }
    }
}

enum class Screen { HOME, CHAT, TASKS, ENCYCLOPEDIA, STUDIO }

class TawaamiViewModelFactory(private val context: Context) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        TawaamiViewModel(context) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TawaamiApp() {
    val context = LocalContext.current.applicationContext
    val vm: TawaamiViewModel = viewModel(factory = TawaamiViewModelFactory(context))
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    val titles = mapOf(
        Screen.HOME to "توائمي 🫂",
        Screen.CHAT to "المحادثة",
        Screen.TASKS to "المهام والمشاريع",
        Screen.ENCYCLOPEDIA to "الموسوعة",
        Screen.STUDIO to "استوديو توائمي"
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            SmallTopAppBar(
                title = { Text(titles[screen] ?: "توائمي", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = Color(0xFFFFF8FB)
                )
            )
        },
        bottomBar = {
            NavigationBar(modifier = Modifier.navigationBarsPadding()) {
                listOf(
                    Triple(Screen.HOME, Icons.Default.Home, "الرئيسية"),
                    Triple(Screen.CHAT, Icons.Default.Edit, "الدردشة"),
                    Triple(Screen.TASKS, Icons.Default.TaskAlt, "المهام"),
                    Triple(Screen.ENCYCLOPEDIA, Icons.Default.MenuBook, "الموسوعة"),
                    Triple(Screen.STUDIO, Icons.Default.Person, "الاستوديو")
                ).forEach { (s, icon, label) ->
                    NavigationBarItem(
                        selected = screen == s,
                        onClick = { screen = s },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        when (screen) {
            Screen.HOME -> HomeScreen(vm, pad) { screen = Screen.CHAT }
            Screen.CHAT -> ChatScreen(vm, pad)
            Screen.TASKS -> TasksScreen(vm, pad)
            Screen.ENCYCLOPEDIA -> EncyclopediaScreen(pad)
            Screen.STUDIO -> StudioScreen(vm, pad)
        }
    }
}

@Composable
fun HomeScreen(vm: TawaamiViewModel, pad: PaddingValues, openChat: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEEF6)),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Avatar(face = "😊", hair = vm.hair, eyes = vm.eyes, style = vm.style, modifier = Modifier.size(150.dp)) {
                        haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("مرحباً ${vm.nickname} 💖", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("رفيقك الرقمي الشخصي لإدارة الحوار والمهام والمعرفة.", modifier = Modifier.padding(top = 6.dp))
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = openChat) { Text("ابدأ المحادثة") }
                }
            }
        }
        item {
            QuickCard("🧠", "الذاكرة", "${vm.memories.size} عنصر محفوظ") { }
        }
        item {
            QuickCard("✅", "المهام", "${vm.tasks.count { !it.done }} مهمة غير مكتملة") { }
        }
        item {
            QuickCard("📚", "الموسوعة", "معرفة محلية قابلة للتوسعة") { }
        }
        item {
            QuickCard("🎙️", "الصوت والكاميرا", "إدخال صوتي وفتح الكاميرا من الدردشة") { }
        }
    }
}

@Composable
fun QuickCard(icon: String, title: String, sub: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(modifier = Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun Avatar(face: String, hair: String, eyes: String, style: String, modifier: Modifier = Modifier, onTap: () -> Unit) {
    val hairEmoji = when (hair) {
        "أشقر" -> "🌟"
        "بني" -> "🟤"
        "أحمر" -> "🟥"
        else -> "⚫"
    }
    val eyesEmoji = when (eyes) {
        "أزرق" -> "🔵"
        "أخضر" -> "🟢"
        "عسلي" -> "🟠"
        else -> "🟤"
    }
    Surface(
        modifier = modifier.clip(CircleShape).clickable { onTap() },
        color = if (style == "أنمي") Color(0xFFFFF0F5) else Color(0xFFFFF7FB),
        shape = CircleShape,
        border = BorderStroke(2.dp, Color(0xFFE6B5CF))
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(hairEmoji, style = MaterialTheme.typography.headlineMedium)
            Text("$face $eyesEmoji", style = MaterialTheme.typography.displayMedium)
        }
    }
}

@Composable
fun ChatScreen(vm: TawaamiViewModel, pad: PaddingValues) {
    var input by rememberSaveable { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    val microphonePermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
            }
            listening = true
            speechLauncher.launch(intent)
        }
    }
    val cameraPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) cameraLauncher.launch(null)
    }

    LaunchedEffect(Unit) {
        tts = TextToSpeech(context) { }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) {
            input = text
            listening = false
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            vm.send("التقطت صورة بالكاميرا. رجاءً هيّئ تحليل الصورة في هذه النسخة.")
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(pad)) {
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            reverseLayout = false,
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(vm.messages) { msg ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (msg.mine) Arrangement.Start else Arrangement.End
                ) {
                    Surface(
                        color = if (msg.mine) Color(0xFFEFF7FF) else Color(0xFFFFEEF6),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(msg.text)
                            Text(msg.time, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            if (!msg.mine) {
                                Text(
                                    "🔊",
                                    modifier = Modifier.clickable {
                                        tts?.speak(msg.text, TextToSpeech.QUEUE_FLUSH, null, "tawaami")
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
                    }
                    listening = true
                    speechLauncher.launch(intent)
                } else {
                    microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            }) {
                Icon(Icons.Default.Mic, contentDescription = "صوت")
            }
            IconButton(onClick = {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    cameraLauncher.launch(null)
                } else {
                    cameraPermission.launch(Manifest.permission.CAMERA)
                }
            }) {
                Icon(Icons.Default.CameraAlt, contentDescription = "كاميرا")
            }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (listening) "استماع..." else "اكتب ما تريد") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                maxLines = 4
            )
            IconButton(onClick = {
                val send = input.trim()
                if (send.isNotBlank()) {
                    vm.send(send)
                    input = ""
                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                }
            }) {
                Icon(Icons.Default.Send, contentDescription = "إرسال")
            }
        }
    }
}

@Composable
fun TasksScreen(vm: TawaamiViewModel, pad: PaddingValues) {
    var newTask by rememberSaveable { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().padding(pad).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = newTask,
                onValueChange = { newTask = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("أضف مهمة أو خطوة مشروع") }
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = {
                vm.addTask(newTask)
                newTask = ""
            }) { Icon(Icons.Default.Add, contentDescription = "إضافة") }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.tasks, key = { it.id }) { task ->
                Card {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { vm.toggleTask(task.id) }) {
                            Icon(Icons.Default.Check, contentDescription = "تغيير الحالة",
                                tint = if (task.done) Color(0xFF2E7D32) else Color.Gray)
                        }
                        Text(
                            task.title,
                            modifier = Modifier.weight(1f),
                            fontWeight = if (task.done) FontWeight.Normal else FontWeight.SemiBold
                        )
                        IconButton(onClick = { vm.deleteTask(task.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EncyclopediaScreen(pad: PaddingValues) {
    val entries = listOf(
        "الذكاء الاصطناعي" to "مجموعة تقنيات تمكّن الأنظمة من تنفيذ مهام تتطلب عادةً فهماً أو استدلالاً أو تعلماً.",
        "البرمجة" to "عملية بناء البرامج عبر تعليمات وقواعد منظمة لحل مشكلة أو تنفيذ وظيفة.",
        "التعلّم" to "تطوير المعرفة أو المهارة من خلال الدراسة والتجربة والممارسة.",
        "الأمن الرقمي" to "مجموعة ممارسات لحماية الأجهزة والحسابات والبيانات من الوصول غير المصرّح به.",
        "التخطيط" to "تحويل الهدف إلى خطوات وموارد وترتيب زمني ومؤشرات إنجاز."
    )
    var selected by rememberSaveable { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxSize().padding(pad).padding(14.dp)) {
        Text("قاعدة معرفة محلية", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries.indices.toList()) { index ->
                FilterChip(
                    selected = selected == index,
                    onClick = { selected = index },
                    label = { Text(entries[index].first) }
                )
            }
        }
        Divider(modifier = Modifier.padding(vertical = 10.dp))
        Text(entries[selected].first, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(entries[selected].second)
        Spacer(Modifier.height(16.dp))
        Text(
            "هذه النواة قابلة لإضافة آلاف المقالات والملفات والمصادر لاحقاً.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun StudioScreen(vm: TawaamiViewModel, pad: PaddingValues) {
    var nickname by rememberSaveable(vm.nickname) { mutableStateOf(vm.nickname) }
    var style by rememberSaveable(vm.style) { mutableStateOf(vm.style) }
    var hair by rememberSaveable(vm.hair) { mutableStateOf(vm.hair) }
    var eyes by rememberSaveable(vm.eyes) { mutableStateOf(vm.eyes) }
    var voice by rememberSaveable(vm.voice) { mutableStateOf(vm.voice) }
    var memoryText by rememberSaveable { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Avatar(face = "😊", hair = hair, eyes = eyes, style = style, modifier = Modifier.size(170.dp)) { }
            }
        }
        item {
            OutlinedTextField(nickname, { nickname = it }, label = { Text("الاسم الذي يناديني/أناديك به") }, modifier = Modifier.fillMaxWidth())
        }
        item {
            Text("النمط")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("واقعي", "أنمي").forEach { x ->
                    FilterChip(selected = style == x, onClick = { style = x }, label = { Text(x) })
                }
            }
        }
        item {
            Text("الشعر")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("أسود", "بني", "أشقر", "أحمر").forEach { x ->
                    FilterChip(selected = hair == x, onClick = { hair = x }, label = { Text(x) })
                }
            }
        }
        item {
            Text("العينان")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("بني", "أزرق", "أخضر", "عسلي").forEach { x ->
                    FilterChip(selected = eyes == x, onClick = { eyes = x }, label = { Text(x) })
                }
            }
        }
        item {
            Text("الصوت / الأسلوب")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("هادئ", "مرح", "رسمي").forEach { x ->
                    FilterChip(selected = voice == x, onClick = { voice = x }, label = { Text(x) })
                }
            }
        }
        item {
            Button(
                onClick = { vm.saveStudio(nickname, style, hair, eyes, voice) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("حفظ شخصية توائمي") }
        }
        item {
            Card {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("ذاكرة شخصية", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = memoryText,
                        onValueChange = { memoryText = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("مثلاً: أحب أن تكون الإجابات مختصرة...") }
                    )
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = {
                        vm.addMemory(memoryText)
                        memoryText = ""
                    }) { Text("حفظ في الذاكرة") }
                    if (vm.memories.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        vm.memories.forEach { mem ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("• ${mem.text}", modifier = Modifier.weight(1f))
                                IconButton(onClick = { vm.deleteMemory(mem.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
```

## FILE: `app/src/main/res/values/styles.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.Tawaami" parent="android:style/Theme.Material.Light.NoActionBar">
        <item name="android:fontFamily">sans</item>
        <item name="android:windowLightStatusBar">true</item>
        <item name="android:statusBarColor">#FFF8FB</item>
        <item name="android:navigationBarColor">#FFF8FB</item>
    </style>
</resources>
```

## FILE: `app/src/main/res/values/strings.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">توائمي 🫂</string>
</resources>
```
