package com.tawaami.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** AI provider settings. API keys are encrypted with a device-bound Android Keystore AES key. */
data class TawaamiProviderConfig(
    val baseUrl: String = "https://api.openai.com/v1",
    val model: String = "gpt-4o-mini",
    val hasApiKey: Boolean = false
)

class TawaamiProviderSettings(context: Context) {
    private val prefs = context.getSharedPreferences("tawaami_ai_provider", Context.MODE_PRIVATE)
    private val alias = "tawaami_ai_api_key_v1"

    fun load(): TawaamiProviderConfig = TawaamiProviderConfig(
        baseUrl = prefs.getString("base_url", "https://api.openai.com/v1") ?: "https://api.openai.com/v1",
        model = prefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini",
        hasApiKey = prefs.contains("key_cipher") && prefs.contains("key_iv")
    )

    fun save(baseUrl: String, model: String, apiKey: String) {
        val normalizedUrl = baseUrl.trim().ifBlank { "https://api.openai.com/v1" }.trimEnd('/')
        val normalizedModel = model.trim().ifBlank { "gpt-4o-mini" }
        prefs.edit().putString("base_url", normalizedUrl).putString("model", normalizedModel).apply()
        if (apiKey.isNotBlank()) encryptAndStore(apiKey.trim())
    }

    fun clearApiKey() {
        prefs.edit().remove("key_cipher").remove("key_iv").apply()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (ks.containsAlias(alias)) ks.deleteEntry(alias)
    }

    fun hasApiKey(): Boolean = load().hasApiKey

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun encryptAndStore(plainText: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(plainText.toByteArray(StandardCharsets.UTF_8))
        prefs.edit()
            .putString("key_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("key_cipher", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .apply()
    }

    fun readApiKey(): String? {
        val ivText = prefs.getString("key_iv", null) ?: return null
        val encryptedText = prefs.getString("key_cipher", null) ?: return null
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                Cipher.DECRYPT_MODE,
                getOrCreateKey(),
                GCMParameterSpec(128, Base64.decode(ivText, Base64.NO_WRAP))
            )
            String(cipher.doFinal(Base64.decode(encryptedText, Base64.NO_WRAP)), StandardCharsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }
}

/** Implements the common OpenAI-compatible Chat Completions interface; the app never ships a secret key. */
class OpenAiCompatibleProvider(private val settings: TawaamiProviderSettings) {
    fun complete(systemPrompt: String, history: List<ChatMessage>, imageDataUrls: List<String> = emptyList()): String {
        val config = settings.load()
        val apiKey = settings.readApiKey()
            ?: throw IllegalStateException("لم يُحفظ مفتاح API صالح. افتح الإعدادات وأضف المفتاح الذي تملكه.")
        val base = config.baseUrl.trimEnd('/')
        val endpoint = if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt))
        val recentHistory = history.takeLast(24)
        recentHistory.forEachIndexed { index, item ->
            val isFinalUserTurnWithImage = imageDataUrls.isNotEmpty() && index == recentHistory.lastIndex && item.mine
            if (isFinalUserTurnWithImage) {
                val content = JSONArray().put(JSONObject().put("type", "text").put("text", item.text))
                imageDataUrls.take(3).forEach { dataUrl ->
                    content.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", dataUrl)))
                }
                messages.put(JSONObject().put("role", "user").put("content", content))
            } else {
                messages.put(JSONObject().put("role", if (item.mine) "user" else "assistant").put("content", item.text))
            }
        }
        val body = JSONObject()
            .put("model", config.model)
            .put("messages", messages)
            .put("temperature", 0.7)

        val connection = URL(endpoint).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15_000
            connection.readTimeout = 90_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("Authorization", "Bearer $apiKey")
            connection.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = runCatching { JSONObject(responseText).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IllegalStateException("تعذّر طلب الذكاء الاصطناعي (HTTP $code). ${detail?.takeIf { it.isNotBlank() } ?: "تحقق من الرابط والمفتاح واسم النموذج والاتصال."}")
            }
            val content = JSONObject(responseText).optJSONArray("choices")
                ?.optJSONObject(0)?.optJSONObject("message")?.opt("content")
            return when (content) {
                is String -> content.trim().ifBlank { "وصل رد فارغ من المزوّد." }
                is JSONArray -> (0 until content.length()).mapNotNull { i ->
                    content.optJSONObject(i)?.optString("text")?.takeIf { it.isNotBlank() }
                }.joinToString("\n").ifBlank { "وصل رد لا يحتوي نصاً قابلاً للعرض." }
                else -> throw IllegalStateException("استجابة المزوّد لا تحتوي على نص رد متوقع.")
            }
        } finally {
            connection.disconnect()
        }
    }
}
