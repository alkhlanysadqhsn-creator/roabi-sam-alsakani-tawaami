package com.tawaami.app

import org.json.JSONObject

/** Stable, model-independent profile for the user's digital companion. */
data class TawaamiAvatarProfile(
    val id: Long,
    val name: String,
    val style: String,
    val hair: String,
    val eyes: String,
    val voice: String,
    val skinTone: String,
    val hairstyle: String,
    val faceShape: String,
    val bodyShape: String,
    val height: String,
    val outfit: String,
    val accessory: String,
    val expression: String,
    val relationship: String,
    val personality: String,
    val speechStyle: String,
    val formality: String,
    val affectionLevel: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("style", style).put("hair", hair)
        .put("eyes", eyes).put("voice", voice).put("skinTone", skinTone)
        .put("hairstyle", hairstyle).put("faceShape", faceShape).put("bodyShape", bodyShape)
        .put("height", height).put("outfit", outfit).put("accessory", accessory)
        .put("expression", expression).put("relationship", relationship).put("personality", personality)
        .put("speechStyle", speechStyle).put("formality", formality).put("affectionLevel", affectionLevel)

    companion object {
        fun fromJson(obj: JSONObject): TawaamiAvatarProfile = TawaamiAvatarProfile(
            id = obj.optLong("id"), name = obj.optString("name", "توائمي"),
            style = obj.optString("style", "واقعي"), hair = obj.optString("hair", "أسود"),
            eyes = obj.optString("eyes", "بني"), voice = obj.optString("voice", "هادئ"),
            skinTone = obj.optString("skinTone", "قمحي"), hairstyle = obj.optString("hairstyle", "قصير"),
            faceShape = obj.optString("faceShape", "بيضاوي"), bodyShape = obj.optString("bodyShape", "متوسط"),
            height = obj.optString("height", "متوسط"), outfit = obj.optString("outfit", "يومي"),
            accessory = obj.optString("accessory", "لا شيء"), expression = obj.optString("expression", "ودود"),
            relationship = obj.optString("relationship", "رفيق"), personality = obj.optString("personality", "حنون"),
            speechStyle = obj.optString("speechStyle", "طبيعي"), formality = obj.optString("formality", "متوازن"),
            affectionLevel = obj.optString("affectionLevel", "دافئ")
        )
    }
}
