package com.tawaami.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Xml
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.json.JSONArray
import org.json.JSONObject
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ChatMessage(val text: String, val mine: Boolean, val time: String)
data class TawaamiTask(val id: Long, val title: String, val done: Boolean)
data class TawaamiMemory(val id: Long, val text: String)
data class TawaamiProject(val id: Long, val title: String, val description: String, val status: String = "نشط")

class TawaamiRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("tawaami_store", Context.MODE_PRIVATE)
    private val localDataKeyAlias = "tawaami_local_data_v1"

    private fun localDataKey(): javax.crypto.SecretKey {
        val keyStore = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(localDataKeyAlias, null) as? javax.crypto.SecretKey)?.let { return it }
        val generator = javax.crypto.KeyGenerator.getInstance(android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            android.security.keystore.KeyGenParameterSpec.Builder(
                localDataKeyAlias,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun savePrivateString(key: String, value: String) {
        val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, localDataKey())
        val encrypted = cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        prefs.edit().putString("private_$key", Base64.encodeToString(encrypted, Base64.NO_WRAP)).remove(key).apply()
    }

    private fun privateString(key: String): String? {
        val encoded = prefs.getString("private_$key", null)
        if (encoded != null) return try {
            val packed = Base64.decode(encoded, Base64.NO_WRAP)
            require(packed.size > 12) { "البيانات المشفرة غير صالحة" }
            val iv = packed.copyOfRange(0, 12)
            val ciphertext = packed.copyOfRange(12, packed.size)
            val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(javax.crypto.Cipher.DECRYPT_MODE, localDataKey(), javax.crypto.spec.GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) { null }
        // Migrate prototype plaintext values to encryption at rest the first time they are read.
        val legacy = try { prefs.getString(key, null) } catch (_: ClassCastException) { null } ?: return null
        // Preserve an older record if Keystore migration temporarily fails; do not silently hide user data.
        runCatching { savePrivateString(key, legacy) }
        return legacy
    }

    fun saveMessages(list: List<ChatMessage>) {
        val array = JSONArray()
        list.takeLast(400).forEach { message ->
            array.put(JSONObject().put("text", message.text).put("mine", message.mine).put("time", message.time))
        }
        savePrivateString("chat_history_json", array.toString())
    }

    fun messages(): List<ChatMessage> {
        val raw = privateString("chat_history_json")
            ?: return listOf(ChatMessage("أهلاً بك 🫂 أنا توائمي. لنبدأ من هنا.", false, now()))
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val item = arr.optJSONObject(i) ?: return@mapNotNull null
                ChatMessage(item.optString("text"), item.optBoolean("mine"), item.optString("time"))
            }.ifEmpty { listOf(ChatMessage("أهلاً بك 🫂 أنا توائمي. لنبدأ من هنا.", false, now())) }
        } catch (_: Exception) {
            listOf(ChatMessage("تعذرت قراءة سجل المحادثة القديم؛ يمكنك متابعة محادثة جديدة.", false, now()))
        }
    }

    fun clearAllLocalData() {
        prefs.edit().clear().apply()
        runCatching {
            val keyStore = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (keyStore.containsAlias(localDataKeyAlias)) keyStore.deleteEntry(localDataKeyAlias)
        }
    }

    fun saveProjects(list: List<TawaamiProject>) {
        val array = JSONArray()
        list.forEach { project ->
            array.put(JSONObject().put("id", project.id).put("title", project.title)
                .put("description", project.description).put("status", project.status))
        }
        savePrivateString("projects_json", array.toString())
    }

    fun projects(): List<TawaamiProject> {
        val raw = privateString("projects_json") ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val item = arr.optJSONObject(i) ?: return@mapNotNull null
                TawaamiProject(item.optLong("id"), item.optString("title"), item.optString("description"), item.optString("status", "نشط"))
            }
        } catch (_: Exception) { emptyList() }
    }

    fun saveAvatarProfiles(list: List<TawaamiAvatarProfile>) {
        val array = JSONArray()
        list.forEach { array.put(it.toJson()) }
        savePrivateString("avatar_profiles_json", array.toString())
    }

    fun avatarProfiles(): List<TawaamiAvatarProfile> {
        val raw = privateString("avatar_profiles_json") ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i -> array.optJSONObject(i)?.let(TawaamiAvatarProfile::fromJson) }
        }.getOrDefault(emptyList())
    }

    fun saveProfileValue(key: String, value: String) { savePrivateString("avatar_$key", value) }
    fun profileValue(key: String, default: String): String = privateString("avatar_$key") ?: default

    fun saveNickname(value: String) = savePrivateString("nickname", value)
    fun nickname() = privateString("nickname") ?: "صاحبي"

    fun saveStyle(value: String) = savePrivateString("style", value)
    fun style() = privateString("style") ?: "واقعي"

    fun saveHair(value: String) = savePrivateString("hair", value)
    fun hair() = privateString("hair") ?: "أسود"

    fun saveEyes(value: String) = savePrivateString("eyes", value)
    fun eyes() = privateString("eyes") ?: "بني"

    fun saveVoice(value: String) = savePrivateString("voice", value)
    fun voice() = privateString("voice") ?: "هادئ"

    fun saveMemories(list: List<TawaamiMemory>) {
        val array = JSONArray()
        list.forEach { array.put(JSONObject().put("id", it.id).put("text", it.text)) }
        savePrivateString("memories_json", array.toString())
    }

    fun memories(): List<TawaamiMemory> {
        val json = privateString("memories_json")
        if (json != null) return runCatching {
            val array = JSONArray(json)
            (0 until array.length()).mapNotNull { i ->
                val item = array.optJSONObject(i) ?: return@mapNotNull null
                TawaamiMemory(item.optLong("id"), item.optString("text"))
            }
        }.getOrDefault(emptyList())
        // Migrate delimiter-formatted records from the early prototype.
        return prefs.getString("memories", "").orEmpty().split("\n").mapNotNull {
            val parts = it.split("|", limit = 2)
            if (parts.size == 2) TawaamiMemory(parts[0].toLongOrNull() ?: 0L, parts[1]) else null
        }
    }

    fun saveTasks(list: List<TawaamiTask>) {
        val array = JSONArray()
        list.forEach { array.put(JSONObject().put("id", it.id).put("done", it.done).put("title", it.title)) }
        savePrivateString("tasks_json", array.toString())
    }

    fun tasks(): List<TawaamiTask> {
        val json = privateString("tasks_json")
        if (json != null) return runCatching {
            val array = JSONArray(json)
            (0 until array.length()).mapNotNull { i ->
                val item = array.optJSONObject(i) ?: return@mapNotNull null
                TawaamiTask(item.optLong("id"), item.optString("title"), item.optBoolean("done"))
            }
        }.getOrDefault(emptyList())
        // Migrate delimiter-formatted records from the early prototype.
        return prefs.getString("tasks", "").orEmpty().split("\n").mapNotNull {
            val parts = it.split("|", limit = 3)
            if (parts.size == 3) TawaamiTask(parts[0].toLongOrNull() ?: 0L, parts[2], parts[1] == "true") else null
        }
    }

    fun memoryEnabled(): Boolean = prefs.getBoolean("memory_enabled", true)
    fun setMemoryEnabled(enabled: Boolean) { prefs.edit().putBoolean("memory_enabled", enabled).apply() }
    fun darkMode(): Boolean = prefs.getBoolean("dark_mode", false)
    fun setDarkMode(enabled: Boolean) { prefs.edit().putBoolean("dark_mode", enabled).apply() }

}

class LocalAiEngine {
    fun answer(input: String, memory: List<TawaamiMemory>, tasks: List<TawaamiTask>): String {
        val q = input.trim()
        val lower = q.lowercase(Locale.getDefault())
        return when {
            q.isBlank() -> "أنا معك 🫂 اكتب لي ما تريد."
            lower.contains("مرحبا") || lower.contains("السلام") || lower.contains("اهلا") ->
                "أهلاً بك 🫂 أنا توائمي. أخبرني بما تريد أن نفعله معاً."
            lower.contains("ماذا تستطيع") || lower.contains("مميزات") ->
                "أستطيع مساعدتك في المحادثة، التخطيط، المهام، الموسوعة، الكتابة، الحساب، التنظيم، وتحويل أفكارك إلى خطوات عملية."
            lower.startsWith("تذكر ") -> {
                "تم تجهيز الرسالة للحفظ في الذاكرة. استخدم زر الحفظ من قسم الذاكرة."
            }
            lower.contains("المهام") ->
                "لديك ${tasks.count { !it.done }} مهام غير مكتملة حالياً."
            lower.contains("ذاكرة") ->
                if (memory.isEmpty()) "لا توجد ذاكرة محفوظة بعد." else "لدي ${memory.size} عناصر ذاكرة محفوظة."
            lower.contains("شكرا") || lower.contains("مشكور") ->
                "العفو 🫂 دائماً إلى جانبك في إنجاز ما نستطيع."
            else ->
                "فهمت قصدك: \"$q\".\n\nأستطيع تحويل طلبك إلى خطة أو مهمة، ويمكننا توسيع هذه النواة لاحقاً بمصدر ذكاء اصطناعي فعلي للردود المتقدمة."
        }
    }
}

class TawaamiViewModel(private val appContext: Context) : ViewModel() {
    private val repo = TawaamiRepository(appContext)
    private val engine = LocalAiEngine()
    private val providerSettings = TawaamiProviderSettings(appContext)
    private val aiProvider = OpenAiCompatibleProvider(providerSettings)
    private val workScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    var messages by mutableStateOf(repo.messages())
        private set
    var providerConfig by mutableStateOf(providerSettings.load())
        private set
    var providerBusy by mutableStateOf(false)
        private set
    var providerStatus by mutableStateOf(
        if (providerSettings.hasApiKey()) "تم إعداد مفتاح موفّر AI محلياً على الجهاز." else "الوضع المحلي نشط؛ أضف مفتاح موفّر متوافق لتفعيل الردود السحابية."
    )
        private set
    var tasks by mutableStateOf(repo.tasks())
        private set
    var projects by mutableStateOf(repo.projects())
        private set
    var avatarProfiles by mutableStateOf(repo.avatarProfiles())
        private set
    var memories by mutableStateOf(repo.memories())
        private set
    var memoryEnabled by mutableStateOf(repo.memoryEnabled())
        private set
    var darkMode by mutableStateOf(repo.darkMode())
        private set
    var nickname by mutableStateOf(repo.nickname())
        private set
    var style by mutableStateOf(repo.style())
        private set
    var hair by mutableStateOf(repo.hair())
        private set
    var eyes by mutableStateOf(repo.eyes())
        private set
    var voice by mutableStateOf(repo.voice())
        private set
    var skinTone by mutableStateOf(repo.profileValue("skinTone", "قمحي"))
        private set
    var hairstyle by mutableStateOf(repo.profileValue("hairstyle", "قصير"))
        private set
    var faceShape by mutableStateOf(repo.profileValue("faceShape", "بيضاوي"))
        private set
    var bodyShape by mutableStateOf(repo.profileValue("bodyShape", "متوسط"))
        private set
    var height by mutableStateOf(repo.profileValue("height", "متوسط"))
        private set
    var outfit by mutableStateOf(repo.profileValue("outfit", "يومي"))
        private set
    var accessory by mutableStateOf(repo.profileValue("accessory", "لا شيء"))
        private set
    var expression by mutableStateOf(repo.profileValue("expression", "ودود"))
        private set
    var relationship by mutableStateOf(repo.profileValue("relationship", "رفيق"))
        private set
    var personality by mutableStateOf(repo.profileValue("personality", "حنون"))
        private set
    var speechStyle by mutableStateOf(repo.profileValue("speechStyle", "طبيعي"))
        private set
    var formality by mutableStateOf(repo.profileValue("formality", "متوازن"))
        private set
    var affectionLevel by mutableStateOf(repo.profileValue("affectionLevel", "دافئ"))
        private set

    fun send(text: String) = sendInternal(text, emptyList())

    fun sendWithImages(text: String, imageDataUrls: List<String>) = sendInternal(text, imageDataUrls)

    private fun sendInternal(text: String, imageDataUrls: List<String>) {
        if (text.isBlank() || providerBusy) return
        val userMessage = ChatMessage(text.trim(), true, now())
        messages = messages + userMessage
        repo.saveMessages(messages)
        if (!providerSettings.hasApiKey()) {
            val answer = if (imageDataUrls.isNotEmpty()) {
                "تم إرفاق صورة، لكن وضع التشغيل المحلي لا يتضمن نموذج رؤية لتحليلها. أضف موفّراً ونموذجاً يدعمان الصور من الإعدادات؛ لم أزعم أن الصورة حُلّلت."
            } else engine.answer(text, if (memoryEnabled) memories else emptyList(), tasks)
            messages = messages + ChatMessage(answer, false, now())
            repo.saveMessages(messages)
            providerStatus = "الرد الحالي محلي بقواعد أساسية؛ لم يتم الاتصال بنموذج AI خارجي."
            return
        }
        providerBusy = true
        providerStatus = "جارٍ الاتصال بموفّر الذكاء الاصطناعي…"
        val history = messages.filter { it.text.isNotBlank() }
        val memoryContext = if (memoryEnabled) memories.take(30).joinToString("\n") { "- ${it.text}" } else "معطّلة من إعدادات الخصوصية؛ لا تستخدم ذاكرة شخصية."
        val taskContext = tasks.filter { !it.done }.take(20).joinToString("\n") { "- ${it.title}" }
        val projectContext = projects.take(20).joinToString("\n") { "- ${it.title} (${it.status}): ${it.description}" }
        val systemPrompt = """أنت توائمي، رفيق رقمي مساعد يتحدث العربية بشكل طبيعي ودافئ. كن صريحاً بشأن ما تعرفه وما تستطيع تنفيذه. لا تدّع تنفيذ أعمال لم تنفذها. حافظ على الخصوصية.

ملف الشخصية الحالي الذي اختاره المستخدم:
الاسم: $nickname؛ النمط البصري: $style؛ لون البشرة: $skinTone؛ شكل الوجه: $faceShape؛ الشعر: $hairstyle ($hair)؛ العينان: $eyes؛ القوام: $bodyShape؛ الطول: $height؛ الملابس: $outfit؛ الإكسسوارات: $accessory؛ التعبير: $expression؛ نمط العلاقة: $relationship؛ الشخصية: $personality؛ أسلوب الكلام: $speechStyle؛ الرسمية: $formality؛ مستوى الدفء: $affectionLevel؛ الصوت المفضل للنطق: $voice.
التزم بهذه التفضيلات في أسلوب الخطاب حيثما كانت مناسبة. هذه الإعدادات تصف أسلوب المساعد ولا تعني أن التطبيق كائن بشري.

ذاكرة سمح المستخدم بحفظها:
$memoryContext

المهام غير المكتملة:
$taskContext

المشاريع المحفوظة:
$projectContext"""
        workScope.launch {
            try {
                val answer = withContext(Dispatchers.IO) { aiProvider.complete(systemPrompt, history, imageDataUrls) }
                messages = messages + ChatMessage(answer, false, now())
                repo.saveMessages(messages)
                providerStatus = "متصل: تم استلام رد من الموفّر المحدد."
            } catch (e: Exception) {
                val reason = e.message?.take(500) ?: "خطأ اتصال غير معروف."
                messages = messages + ChatMessage("تعذّر الحصول على رد من موفّر AI. لم أستبدل الرد بإجابة وهمية.\nالتفاصيل: $reason", false, now())
                repo.saveMessages(messages)
                providerStatus = "فشل الاتصال: $reason"
            } finally {
                providerBusy = false
            }
        }
    }

    fun reportStatus(message: String) { providerStatus = message.take(600) }

    fun saveProvider(baseUrl: String, model: String, apiKey: String) {
        try {
            providerSettings.save(baseUrl, model, apiKey)
            providerConfig = providerSettings.load()
            providerStatus = if (providerConfig.hasApiKey) "حُفظت الإعدادات؛ المفتاح مشفّر باستخدام Android Keystore على هذا الجهاز." else "حُفظ رابط الموفّر واسم النموذج. الوضع المحلي مستمر حتى إضافة مفتاح API."
        } catch (e: Exception) {
            providerStatus = "تعذّر حفظ مفتاح API بصورة آمنة على هذا الجهاز: ${e.message ?: "خطأ غير معروف"}"
        }
    }

    fun removeApiKey() {
        providerSettings.clearApiKey()
        providerConfig = providerSettings.load()
        providerStatus = "تم حذف مفتاح API المحفوظ. ستعمل المحادثة محلياً حتى تضيف مفتاحاً جديداً."
    }

    fun testProviderConnection() {
        if (providerBusy) return
        if (!providerSettings.hasApiKey()) {
            providerStatus = "أضف مفتاح API أولاً؛ لم يُجرَ أي اتصال."
            return
        }
        providerBusy = true
        providerStatus = "جارٍ اختبار عنوان الخدمة والمفتاح واسم النموذج…"
        workScope.launch {
            try {
                val answer = withContext(Dispatchers.IO) {
                    aiProvider.complete(
                        "أنت في اختبار اتصال تقني. أجب بكلمة واحدة فقط: تم.",
                        listOf(ChatMessage("اختبار اتصال. أجب بكلمة واحدة فقط: تم.", true, now()))
                    )
                }
                providerStatus = "نجح اختبار الاتصال الفعلي. ردّ النموذج: ${answer.take(140)}"
            } catch (e: Exception) {
                providerStatus = "فشل اختبار الاتصال: ${e.message?.take(450) ?: "خطأ اتصال غير معروف"}"
            } finally {
                providerBusy = false
            }
        }
    }

    fun setDarkMode(enabled: Boolean) {
        darkMode = enabled
        repo.setDarkMode(enabled)
    }

    fun setMemoryEnabled(enabled: Boolean) {
        memoryEnabled = enabled
        repo.setMemoryEnabled(enabled)
        providerStatus = if (enabled) "تم تفعيل استخدام الذاكرة المحفوظة." else "تم تعطيل استخدام الذاكرة؛ البيانات المحفوظة لم تُحذف ويمكن حذفها من الاستوديو."
    }

    fun importDataJson(raw: String): Boolean {
        return try {
            require(raw.length <= 4_000_000) { "ملف الاستيراد أكبر من الحد المسموح." }
            val root = JSONObject(raw)
            require(root.optString("format") == "tawaami-export-v1") { "صيغة الملف ليست نسخة تصدير معروفة من توائمي." }
            val newMessages = root.optJSONArray("messages")?.let { a -> (0 until a.length()).mapNotNull { i ->
                val m = a.optJSONObject(i) ?: return@mapNotNull null
                ChatMessage(m.optString("text"), m.optBoolean("mine"), m.optString("time"))
            } } ?: emptyList()
            val newMemories = root.optJSONArray("memories")?.let { a -> (0 until a.length()).mapNotNull { i ->
                val m = a.optJSONObject(i) ?: return@mapNotNull null
                TawaamiMemory(m.optLong("id"), m.optString("text"))
            } } ?: emptyList()
            val newTasks = root.optJSONArray("tasks")?.let { a -> (0 until a.length()).mapNotNull { i ->
                val t = a.optJSONObject(i) ?: return@mapNotNull null
                TawaamiTask(t.optLong("id"), t.optString("title"), t.optBoolean("done"))
            } } ?: emptyList()
            val newProjects = root.optJSONArray("projects")?.let { a -> (0 until a.length()).mapNotNull { i ->
                val item = a.optJSONObject(i) ?: return@mapNotNull null
                TawaamiProject(item.optLong("id"), item.optString("title"), item.optString("description"), item.optString("status", "نشط"))
            } } ?: emptyList()
            val newAvatarProfiles = root.optJSONArray("avatarProfiles")?.let { a -> (0 until a.length()).mapNotNull { i ->
                a.optJSONObject(i)?.let(TawaamiAvatarProfile::fromJson)
            } } ?: emptyList()
            nickname = root.optString("nickname", nickname)
            style = root.optString("style", style)
            hair = root.optString("hair", hair)
            eyes = root.optString("eyes", eyes)
            voice = root.optString("voice", voice)
            skinTone = root.optString("skinTone", skinTone); hairstyle = root.optString("hairstyle", hairstyle)
            faceShape = root.optString("faceShape", faceShape); bodyShape = root.optString("bodyShape", bodyShape)
            height = root.optString("height", height); outfit = root.optString("outfit", outfit); accessory = root.optString("accessory", accessory)
            expression = root.optString("expression", expression); relationship = root.optString("relationship", relationship)
            personality = root.optString("personality", personality); speechStyle = root.optString("speechStyle", speechStyle)
            formality = root.optString("formality", formality); affectionLevel = root.optString("affectionLevel", affectionLevel)
            mapOf("skinTone" to skinTone, "hairstyle" to hairstyle, "faceShape" to faceShape, "bodyShape" to bodyShape,
                "height" to height, "outfit" to outfit, "accessory" to accessory, "expression" to expression,
                "relationship" to relationship, "personality" to personality, "speechStyle" to speechStyle,
                "formality" to formality, "affectionLevel" to affectionLevel).forEach { (key, value) -> repo.saveProfileValue(key, value) }
            memoryEnabled = root.optBoolean("memoryEnabled", true)
            repo.setMemoryEnabled(memoryEnabled)
            darkMode = root.optBoolean("darkMode", darkMode)
            repo.setDarkMode(darkMode)
            repo.saveNickname(nickname); repo.saveStyle(style); repo.saveHair(hair); repo.saveEyes(eyes); repo.saveVoice(voice)
            messages = newMessages.ifEmpty { listOf(ChatMessage("تم استيراد البيانات بنجاح 🫂", false, now())) }
            memories = newMemories; tasks = newTasks; projects = newProjects; avatarProfiles = newAvatarProfiles
            repo.saveMessages(messages); repo.saveMemories(memories); repo.saveTasks(tasks); repo.saveProjects(projects); repo.saveAvatarProfiles(avatarProfiles)
            providerStatus = "تم استيراد المحادثات والذاكرة والمهام والمشاريع وإعدادات الشخصية. لم يتم استيراد مفاتيح API لأسباب أمنية."
            true
        } catch (e: Exception) {
            providerStatus = "تعذر استيراد البيانات: ${e.message ?: "ملف غير صالح"}"
            false
        }
    }

    fun exportDataJson(): String {
        val root = JSONObject()
        root.put("format", "tawaami-export-v1")
        root.put("exportedAt", System.currentTimeMillis())
        root.put("nickname", nickname)
        root.put("style", style)
        root.put("hair", hair)
        root.put("eyes", eyes)
        root.put("voice", voice)
        root.put("skinTone", skinTone); root.put("hairstyle", hairstyle); root.put("faceShape", faceShape)
        root.put("bodyShape", bodyShape); root.put("height", height); root.put("outfit", outfit); root.put("accessory", accessory)
        root.put("expression", expression); root.put("relationship", relationship); root.put("personality", personality)
        root.put("speechStyle", speechStyle); root.put("formality", formality); root.put("affectionLevel", affectionLevel)
        root.put("memoryEnabled", memoryEnabled)
        root.put("darkMode", darkMode)
        root.put("messages", JSONArray().also { a -> messages.forEach { a.put(JSONObject().put("text", it.text).put("mine", it.mine).put("time", it.time)) } })
        root.put("memories", JSONArray().also { a -> memories.forEach { a.put(JSONObject().put("id", it.id).put("text", it.text)) } })
        root.put("tasks", JSONArray().also { a -> tasks.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done)) } })
        root.put("projects", JSONArray().also { a -> projects.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("description", it.description).put("status", it.status)) } })
        root.put("avatarProfiles", JSONArray().also { a -> avatarProfiles.forEach { a.put(it.toJson()) } })
        return root.toString(2)
    }

    fun deleteUserData() {
        repo.clearAllLocalData()
        messages = listOf(ChatMessage("تم حذف البيانات المحلية. أهلاً بك من جديد 🫂", false, now()))
        tasks = emptyList()
        projects = emptyList()
        avatarProfiles = emptyList()
        memories = emptyList()
        nickname = "صاحبي"
        style = "واقعي"
        hair = "أسود"
        eyes = "بني"
        voice = "هادئ"
        skinTone = "قمحي"; hairstyle = "قصير"; faceShape = "بيضاوي"; bodyShape = "متوسط"
        height = "متوسط"; outfit = "يومي"; accessory = "لا شيء"; expression = "ودود"
        relationship = "رفيق"; personality = "حنون"; speechStyle = "طبيعي"; formality = "متوازن"; affectionLevel = "دافئ"
        memoryEnabled = true
        repo.setMemoryEnabled(true)
        darkMode = false
        repo.setDarkMode(false)
        repo.saveMessages(messages)
        repo.saveTasks(tasks)
        repo.saveProjects(projects)
        repo.saveMemories(memories)
        repo.saveAvatarProfiles(avatarProfiles)
        runCatching { providerSettings.clearAll() }
        providerConfig = providerSettings.load()
        providerStatus = "حُذفت البيانات المحلية وإعدادات الموفّر ومفتاح API المحفوظ. راجع الملفات التي صدّرتها خارج التطبيق بصورة منفصلة."
    }

    override fun onCleared() {
        workScope.cancel()
        super.onCleared()
    }

    fun addTask(title: String) {
        if (title.isBlank()) return
        val item = TawaamiTask(System.currentTimeMillis(), title.trim(), false)
        tasks = tasks + item
        repo.saveTasks(tasks)
    }

    fun addProject(title: String, description: String) {
        if (title.isBlank()) return
        projects = projects + TawaamiProject(System.currentTimeMillis(), title.trim(), description.trim())
        repo.saveProjects(projects)
    }

    fun cycleProjectStatus(id: Long) {
        projects = projects.map { project ->
            if (project.id != id) project else project.copy(status = when (project.status) {
                "نشط" -> "متوقف"
                "متوقف" -> "مكتمل"
                else -> "نشط"
            })
        }
        repo.saveProjects(projects)
    }

    fun deleteProject(id: Long) {
        projects = projects.filterNot { it.id == id }
        repo.saveProjects(projects)
    }

    fun toggleTask(id: Long) {
        tasks = tasks.map { if (it.id == id) it.copy(done = !it.done) else it }
        repo.saveTasks(tasks)
    }

    fun deleteTask(id: Long) {
        tasks = tasks.filterNot { it.id == id }
        repo.saveTasks(tasks)
    }

    fun addMemory(text: String) {
        if (text.isBlank()) return
        memories = memories + TawaamiMemory(System.currentTimeMillis(), text.trim())
        repo.saveMemories(memories)
    }

    fun deleteMemory(id: Long) {
        memories = memories.filterNot { it.id == id }
        repo.saveMemories(memories)
    }

    fun saveCurrentProfileAs(profileName: String) {
        val name = profileName.trim().ifBlank { nickname }
        val profile = TawaamiAvatarProfile(
            id = System.currentTimeMillis(), name = name, style = style, hair = hair, eyes = eyes, voice = voice,
            skinTone = skinTone, hairstyle = hairstyle, faceShape = faceShape, bodyShape = bodyShape, height = height,
            outfit = outfit, accessory = accessory, expression = expression, relationship = relationship,
            personality = personality, speechStyle = speechStyle, formality = formality, affectionLevel = affectionLevel
        )
        avatarProfiles = avatarProfiles + profile
        repo.saveAvatarProfiles(avatarProfiles)
    }

    fun applyAvatarProfile(id: Long) {
        val p = avatarProfiles.firstOrNull { it.id == id } ?: return
        saveStudio(p.name, p.style, p.hair, p.eyes, p.voice, p.skinTone, p.hairstyle, p.faceShape,
            p.bodyShape, p.height, p.outfit, p.accessory, p.expression, p.relationship, p.personality,
            p.speechStyle, p.formality, p.affectionLevel)
        providerStatus = "تم تطبيق الشخصية المحفوظة: ${p.name}."
    }

    fun deleteAvatarProfile(id: Long) {
        avatarProfiles = avatarProfiles.filterNot { it.id == id }
        repo.saveAvatarProfiles(avatarProfiles)
    }

    fun saveStudio(
        newNickname: String, newStyle: String, newHair: String, newEyes: String, newVoice: String,
        newSkinTone: String, newHairstyle: String, newFaceShape: String, newBodyShape: String,
        newHeight: String, newOutfit: String, newAccessory: String, newExpression: String,
        newRelationship: String, newPersonality: String, newSpeechStyle: String,
        newFormality: String, newAffectionLevel: String
    ) {
        nickname = newNickname.ifBlank { "صاحبي" }
        style = newStyle; hair = newHair; eyes = newEyes; voice = newVoice
        skinTone = newSkinTone; hairstyle = newHairstyle; faceShape = newFaceShape
        bodyShape = newBodyShape; height = newHeight; outfit = newOutfit; accessory = newAccessory
        expression = newExpression; relationship = newRelationship; personality = newPersonality
        speechStyle = newSpeechStyle; formality = newFormality; affectionLevel = newAffectionLevel
        repo.saveNickname(nickname); repo.saveStyle(style); repo.saveHair(hair); repo.saveEyes(eyes); repo.saveVoice(voice)
        mapOf(
            "skinTone" to skinTone, "hairstyle" to hairstyle, "faceShape" to faceShape,
            "bodyShape" to bodyShape, "height" to height, "outfit" to outfit, "accessory" to accessory,
            "expression" to expression, "relationship" to relationship, "personality" to personality,
            "speechStyle" to speechStyle, "formality" to formality, "affectionLevel" to affectionLevel
        ).forEach { (key, value) -> repo.saveProfileValue(key, value) }
    }
}

private fun now(): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TawaamiApp() }
    }
}

enum class Screen { HOME, CHAT, TASKS, ENCYCLOPEDIA, STUDIO, SETTINGS }

class TawaamiViewModelFactory(private val context: Context) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        TawaamiViewModel(context) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TawaamiApp() {
    val context = LocalContext.current.applicationContext
    val vm: TawaamiViewModel = viewModel(factory = TawaamiViewModelFactory(context))
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    val titles = mapOf(
        Screen.HOME to "توائمي 🫂",
        Screen.CHAT to "المحادثة",
        Screen.TASKS to "المهام والمشاريع",
        Screen.ENCYCLOPEDIA to "الموسوعة",
        Screen.STUDIO to "استوديو توائمي",
        Screen.SETTINGS to "الإعدادات والخصوصية"
    )

    MaterialTheme(colorScheme = if (vm.darkMode) darkColorScheme() else lightColorScheme()) {
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            SmallTopAppBar(
                title = { Text(titles[screen] ?: "توائمي", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(modifier = Modifier.navigationBarsPadding()) {
                listOf(
                    Triple(Screen.HOME, Icons.Default.Home, "الرئيسية"),
                    Triple(Screen.CHAT, Icons.Default.Edit, "الدردشة"),
                    Triple(Screen.TASKS, Icons.Default.TaskAlt, "المهام"),
                    Triple(Screen.ENCYCLOPEDIA, Icons.Default.MenuBook, "الموسوعة"),
                    Triple(Screen.STUDIO, Icons.Default.Person, "الاستوديو"),
                    Triple(Screen.SETTINGS, Icons.Default.Settings, "الإعدادات")
                ).forEach { (s, icon, label) ->
                    NavigationBarItem(
                        selected = screen == s,
                        onClick = { screen = s },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        when (screen) {
            Screen.HOME -> HomeScreen(vm, pad) { screen = Screen.CHAT }
            Screen.CHAT -> ChatScreen(vm, pad)
            Screen.TASKS -> TasksScreen(vm, pad)
            Screen.ENCYCLOPEDIA -> EncyclopediaScreen(pad)
            Screen.STUDIO -> StudioScreen(vm, pad)
            Screen.SETTINGS -> SettingsScreen(vm, pad)
        }
    }
      }
    }
}

@Composable
fun HomeScreen(vm: TawaamiViewModel, pad: PaddingValues, openChat: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEEF6)),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Avatar(face = "😊", hair = vm.hair, eyes = vm.eyes, style = vm.style, skinTone = vm.skinTone, hairstyle = vm.hairstyle, outfit = vm.outfit, accessory = vm.accessory, expression = vm.expression, modifier = Modifier.size(150.dp)) {
                        haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("مرحباً ${vm.nickname} 💖", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("رفيقك الرقمي الشخصي لإدارة الحوار والمهام والمعرفة.", modifier = Modifier.padding(top = 6.dp))
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = openChat) { Text("ابدأ المحادثة") }
                }
            }
        }
        item {
            QuickCard("🧠", "الذاكرة", "${vm.memories.size} عنصر محفوظ") { }
        }
        item {
            QuickCard("✅", "المهام", "${vm.tasks.count { !it.done }} مهمة غير مكتملة") { }
        }
        item {
            QuickCard("📚", "الموسوعة", "معرفة محلية قابلة للتوسعة") { }
        }
        item {
            QuickCard("🎙️", "الصوت والكاميرا", "إدخال صوتي وفتح الكاميرا من الدردشة") { }
        }
    }
}

@Composable
fun QuickCard(icon: String, title: String, sub: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(modifier = Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun Avatar(
    face: String, hair: String, eyes: String, style: String,
    skinTone: String = "قمحي", hairstyle: String = "قصير", outfit: String = "يومي",
    accessory: String = "لا شيء", expression: String = "ودود",
    modifier: Modifier = Modifier, onTap: () -> Unit
) {
    val hairEmoji = when (hair) { "أشقر" -> "🌟"; "بني" -> "🟤"; "أحمر" -> "🟥"; else -> "⚫" }
    val eyesEmoji = when (eyes) { "أزرق" -> "🔵"; "أخضر" -> "🟢"; "عسلي" -> "🟠"; else -> "🟤" }
    val outfitEmoji = when (outfit) { "رسمي" -> "🧥"; "رياضي" -> "🥋"; "أنيق" -> "👗"; "شتوي" -> "🧣"; else -> "👕" }
    val accessoryEmoji = when (accessory) { "نظارات" -> "👓"; "قبعة" -> "🧢"; "سماعات" -> "🎧"; "قلادة" -> "📿"; else -> "" }
    val skinColor = when (skinTone) { "فاتح" -> Color(0xFFFFE7D5); "داكن" -> Color(0xFF8D5B42); "زيتوني" -> Color(0xFFD5B18A); else -> Color(0xFFEAC4A1) }
    val faceEmoji = when (expression) { "فرح" -> "😊"; "تفكير" -> "🤔"; "هادئ" -> "😌"; "مرح" -> "😄"; else -> face }
    Surface(
        modifier = modifier.clip(CircleShape).clickable { onTap() },
        color = if (style == "أنمي") skinColor.copy(alpha = 0.55f) else skinColor.copy(alpha = 0.35f),
        shape = CircleShape, border = BorderStroke(2.dp, Color(0xFFE6B5CF))
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("$hairEmoji  ${if (hairstyle == "طويل") "〰️" else if (hairstyle == "مجعد") "➰" else ""}", style = MaterialTheme.typography.headlineMedium)
            Text("$faceEmoji $eyesEmoji", style = MaterialTheme.typography.displayMedium)
            Text("$outfitEmoji $accessoryEmoji", style = MaterialTheme.typography.titleMedium)
        }
    }
}

private fun uriToImageDataUrl(context: Context, uri: Uri): String? {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        val decoded = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) } ?: return null
        val bitmap = if (maxOf(decoded.width, decoded.height) > 1600) {
            val ratio = 1600f / maxOf(decoded.width, decoded.height)
            Bitmap.createScaledBitmap(decoded, (decoded.width * ratio).toInt(), (decoded.height * ratio).toInt(), true)
        } else decoded
        val output = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 78, output)
        if (bitmap !== decoded) bitmap.recycle()
        if (decoded !== bitmap) decoded.recycle()
        val bytes = output.toByteArray()
        if (bytes.size > 5 * 1024 * 1024) return null
        "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
    } catch (_: Exception) {
        null
    }
}

private fun extractDocumentText(context: Context, uri: Uri): String {
    val mime = context.contentResolver.getType(uri).orEmpty().lowercase(Locale.ROOT)
    val displayName = runCatching {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
        }
    }.getOrDefault("")
    val lowerName = displayName.lowercase(Locale.ROOT)
    return when {
        mime == "application/pdf" || lowerName.endsWith(".pdf") -> {
            PDFBoxResourceLoader.init(context.applicationContext)
            context.contentResolver.openInputStream(uri)?.use { input ->
                PDDocument.load(input).use { document ->
                    if (document.numberOfPages > 250) throw IllegalArgumentException("الملف يتجاوز 250 صفحة في هذه المرحلة.")
                    PDFTextStripper().getText(document).take(700_000)
                }
            } ?: throw IllegalArgumentException("تعذر فتح ملف PDF.")
        }
        mime == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || lowerName.endsWith(".docx") -> {
            val documentXml = context.contentResolver.openInputStream(uri)?.use { source ->
                ZipInputStream(source).use { zip ->
                    var result: String? = null
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        if (entry.name == "word/document.xml") {
                            result = zip.readBytes().toString(Charsets.UTF_8).take(2_000_000)
                            break
                        }
                    }
                    result
                }
            } ?: throw IllegalArgumentException("تعذر فتح ملف Word.")
            val parser = Xml.newPullParser()
            parser.setInput(StringReader(documentXml))
            val out = StringBuilder()
            var inTextNode = false
            var event = parser.eventType
            while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && out.length < 700_000) {
                val tag = parser.name?.substringAfter(':')
                if (event == org.xmlpull.v1.XmlPullParser.START_TAG && tag == "t") inTextNode = true
                if (event == org.xmlpull.v1.XmlPullParser.TEXT && inTextNode) out.append(parser.text)
                if (event == org.xmlpull.v1.XmlPullParser.END_TAG && tag == "t") inTextNode = false
                if (event == org.xmlpull.v1.XmlPullParser.END_TAG && tag == "p") out.append('\n')
                event = parser.next()
            }
            out.toString()
        }
        mime.startsWith("text/") || lowerName.endsWith(".txt") || lowerName.endsWith(".md") || lowerName.endsWith(".csv") || lowerName.endsWith(".json") || lowerName.endsWith(".xml") || lowerName.endsWith(".kt") || lowerName.endsWith(".java") || lowerName.endsWith(".py") -> {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0 || total >= 700_000) break
                    val allowed = minOf(n, 700_000 - total)
                    output.write(buffer, 0, allowed)
                    total += allowed
                }
                output.toString(Charsets.UTF_8.name())
            } ?: throw IllegalArgumentException("تعذر فتح الملف النصي.")
        }
        else -> throw IllegalArgumentException("الصيغ المدعومة حالياً: PDF النصي، DOCX، TXT، Markdown، CSV، JSON، XML وملفات الكود النصية. لم تُحلّل هذه الصيغة.")
    }
}

private fun bitmapToImageDataUrl(bitmap: Bitmap): String? = try {
    val maxSide = maxOf(bitmap.width, bitmap.height)
    val resized = if (maxSide > 1280) {
        val ratio = 1280f / maxSide
        Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
    } else bitmap
    val output = ByteArrayOutputStream()
    resized.compress(Bitmap.CompressFormat.JPEG, 78, output)
    if (resized !== bitmap) resized.recycle()
    val bytes = output.toByteArray()
    if (bytes.size > 5 * 1024 * 1024) null else "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
} catch (_: Exception) { null }

@Composable
fun ChatScreen(vm: TawaamiViewModel, pad: PaddingValues) {
    var input by rememberSaveable { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val chatScope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var startSpeechAfterPermission by remember { mutableStateOf(false) }
    var startCameraAfterPermission by remember { mutableStateOf(false) }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) {
            input = text
            listening = false
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            chatScope.launch {
                val dataUrl = withContext(Dispatchers.IO) { bitmapToImageDataUrl(bitmap) }
                if (dataUrl != null) vm.sendWithImages("حلل الصورة التي التقطتها واشرح ما يظهر فيها، مع توضيح أي شيء غير مؤكد.", listOf(dataUrl))
                else vm.send("تعذر تجهيز الصورة للإرسال. لم يتم تحليلها.")
            }
        }
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            chatScope.launch {
                val dataUrl = withContext(Dispatchers.IO) { uriToImageDataUrl(context, uri) }
                if (dataUrl != null) vm.sendWithImages("حلل الصورة المرفقة واشرح ما يظهر فيها، مع توضيح أي شيء غير مؤكد.", listOf(dataUrl))
                else vm.send("تعذر قراءة الصورة أو أنها كبيرة جداً. لم يتم تحليلها؛ جرّب صورة أصغر.")
            }
        }
    }
    val documentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            chatScope.launch {
                try {
                    val text = withContext(Dispatchers.IO) { extractDocumentText(context, uri) }
                    if (text.isBlank()) vm.send("اخترت مستنداً لكن لم أستطع استخراج نص منه. قد يكون PDF ممسوحاً ضوئياً ويحتاج OCR.")
                    else vm.send("حلّل المستند التالي واستخرج أهم النقاط، واذكر بوضوح ما إذا كان النص غير كافٍ:\n\n$text")
                } catch (e: Exception) {
                    vm.send("تعذرت قراءة المستند. ${e.message ?: "تحقق من صيغة الملف."}")
                }
            }
        }
    }
    val microphonePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        startSpeechAfterPermission = granted
        if (!granted) listening = false
    }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        startCameraAfterPermission = granted
    }
    LaunchedEffect(startSpeechAfterPermission) {
        if (startSpeechAfterPermission) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
            }
            listening = true
            speechLauncher.launch(intent)
            startSpeechAfterPermission = false
        }
    }
    LaunchedEffect(startCameraAfterPermission) {
        if (startCameraAfterPermission) {
            cameraLauncher.launch(null)
            startCameraAfterPermission = false
        }
    }
    DisposableEffect(context) {
        var engineForLocale: TextToSpeech? = null
        val engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engineForLocale?.setLanguage(Locale("ar"))
            } else {
                vm.reportStatus("تعذّرت تهيئة خدمة قراءة النص على هذا الجهاز.")
            }
        }
        engineForLocale = engine
        tts = engine
        onDispose {
            runCatching { engine.stop() }
            runCatching { engine.shutdown() }
            if (tts === engine) tts = null
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(pad)) {
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            reverseLayout = false,
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(vm.messages) { msg ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (msg.mine) Arrangement.Start else Arrangement.End
                ) {
                    Surface(
                        color = if (msg.mine) Color(0xFFEFF7FF) else Color(0xFFFFEEF6),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(msg.text)
                            Text(msg.time, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            if (!msg.mine) {
                                Text(
                                    "🔊",
                                    modifier = Modifier.clickable {
                                        tts?.speak(msg.text, TextToSpeech.QUEUE_FLUSH, null, "tawaami")
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (vm.providerBusy) {
            Text("توائمي يفكر…", modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.primary)
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
                    }
                    listening = true
                    speechLauncher.launch(intent)
                } else {
                    microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            }) {
                Icon(Icons.Default.Mic, contentDescription = "صوت")
            }
            IconButton(onClick = { documentLauncher.launch(arrayOf("application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/*", "application/json", "application/xml")) }) {
                Icon(Icons.Default.AttachFile, contentDescription = "إرفاق مستند")
            }
            IconButton(onClick = { galleryLauncher.launch("image/*") }) {
                Icon(Icons.Default.Image, contentDescription = "إرفاق صورة")
            }
            IconButton(onClick = {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    cameraLauncher.launch(null)
                } else {
                    cameraPermission.launch(Manifest.permission.CAMERA)
                }
            }) {
                Icon(Icons.Default.CameraAlt, contentDescription = "كاميرا")
            }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (listening) "استماع..." else "اكتب ما تريد") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                maxLines = 4
            )
            IconButton(onClick = {
                val send = input.trim()
                if (send.isNotBlank()) {
                    vm.send(send)
                    input = ""
                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                }
            }) {
                Icon(Icons.Default.Send, contentDescription = "إرسال")
            }
        }
    }
}

@Composable
fun TasksScreen(vm: TawaamiViewModel, pad: PaddingValues) {
    var selectedMode by rememberSaveable { mutableStateOf("المهام") }
    var newTask by rememberSaveable { mutableStateOf("") }
    var projectTitle by rememberSaveable { mutableStateOf("") }
    var projectDescription by rememberSaveable { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().padding(pad).padding(14.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("المهام", "المشاريع").forEach { mode ->
                FilterChip(selected = selectedMode == mode, onClick = { selectedMode = mode }, label = { Text(mode) })
            }
        }
        Spacer(Modifier.height(10.dp))
        if (selectedMode == "المهام") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = newTask, onValueChange = { newTask = it }, modifier = Modifier.weight(1f), placeholder = { Text("أضف مهمة أو خطوة مشروع") })
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = { vm.addTask(newTask); newTask = "" }) { Icon(Icons.Default.Add, contentDescription = "إضافة مهمة") }
            }
            Spacer(Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.tasks, key = { it.id }) { task ->
                    Card {
                        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { vm.toggleTask(task.id) }) {
                                Icon(Icons.Default.Check, contentDescription = "تغيير الحالة", tint = if (task.done) Color(0xFF2E7D32) else Color.Gray)
                            }
                            Text(task.title, modifier = Modifier.weight(1f), fontWeight = if (task.done) FontWeight.Normal else FontWeight.SemiBold)
                            IconButton(onClick = { vm.deleteTask(task.id) }) { Icon(Icons.Default.Delete, contentDescription = "حذف") }
                        }
                    }
                }
                if (vm.tasks.isEmpty()) item { Text("لا توجد مهام بعد. أضف أول خطوة هنا.") }
            }
        } else {
            OutlinedTextField(projectTitle, { projectTitle = it }, modifier = Modifier.fillMaxWidth(), label = { Text("اسم المشروع") }, singleLine = true)
            OutlinedTextField(projectDescription, { projectDescription = it }, modifier = Modifier.fillMaxWidth(), label = { Text("وصف المشروع والهدف") }, minLines = 2)
            Button(onClick = { vm.addProject(projectTitle, projectDescription); projectTitle = ""; projectDescription = "" }, modifier = Modifier.fillMaxWidth()) { Text("حفظ المشروع") }
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.projects, key = { it.id }) { project ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text(project.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            if (project.description.isNotBlank()) Text(project.description, modifier = Modifier.padding(top = 4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("الحالة: ${project.status}", modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.primary)
                                OutlinedButton(onClick = { vm.cycleProjectStatus(project.id) }) { Text("تغيير الحالة") }
                                IconButton(onClick = { vm.deleteProject(project.id) }) { Icon(Icons.Default.Delete, contentDescription = "حذف المشروع") }
                            }
                        }
                    }
                }
                if (vm.projects.isEmpty()) item { Text("لا توجد مشاريع محفوظة بعد. أنشئ مشروعاً لتبدأ حفظ حالته محلياً.") }
            }
        }
    }
}

@Composable
fun EncyclopediaScreen(pad: PaddingValues) {
    val entries = listOf(
        "الذكاء الاصطناعي" to "مجموعة تقنيات تمكّن الأنظمة من تنفيذ مهام تتطلب عادةً فهماً أو استدلالاً أو تعلماً.",
        "البرمجة" to "عملية بناء البرامج عبر تعليمات وقواعد منظمة لحل مشكلة أو تنفيذ وظيفة.",
        "التعلّم" to "تطوير المعرفة أو المهارة من خلال الدراسة والتجربة والممارسة.",
        "الأمن الرقمي" to "مجموعة ممارسات لحماية الأجهزة والحسابات والبيانات من الوصول غير المصرّح به.",
        "التخطيط" to "تحويل الهدف إلى خطوات وموارد وترتيب زمني ومؤشرات إنجاز."
    )
    var selected by rememberSaveable { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxSize().padding(pad).padding(14.dp)) {
        Text("قاعدة معرفة محلية", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries.indices.toList()) { index ->
                FilterChip(
                    selected = selected == index,
                    onClick = { selected = index },
                    label = { Text(entries[index].first) }
                )
            }
        }
        Divider(modifier = Modifier.padding(vertical = 10.dp))
        Text(entries[selected].first, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(entries[selected].second)
        Spacer(Modifier.height(16.dp))
        Text(
            "هذه النواة قابلة لإضافة آلاف المقالات والملفات والمصادر لاحقاً.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun ChoiceRow(label: String, selected: String, options: List<String>, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, fontWeight = FontWeight.SemiBold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(options) { option ->
                FilterChip(selected = option == selected, onClick = { onSelect(option) }, label = { Text(option) })
            }
        }
    }
}

@Composable
fun StudioScreen(vm: TawaamiViewModel, pad: PaddingValues) {
    var nickname by rememberSaveable(vm.nickname) { mutableStateOf(vm.nickname) }
    var style by rememberSaveable(vm.style) { mutableStateOf(vm.style) }
    var hair by rememberSaveable(vm.hair) { mutableStateOf(vm.hair) }
    var eyes by rememberSaveable(vm.eyes) { mutableStateOf(vm.eyes) }
    var voice by rememberSaveable(vm.voice) { mutableStateOf(vm.voice) }
    var skinTone by rememberSaveable(vm.skinTone) { mutableStateOf(vm.skinTone) }
    var hairstyle by rememberSaveable(vm.hairstyle) { mutableStateOf(vm.hairstyle) }
    var faceShape by rememberSaveable(vm.faceShape) { mutableStateOf(vm.faceShape) }
    var bodyShape by rememberSaveable(vm.bodyShape) { mutableStateOf(vm.bodyShape) }
    var height by rememberSaveable(vm.height) { mutableStateOf(vm.height) }
    var outfit by rememberSaveable(vm.outfit) { mutableStateOf(vm.outfit) }
    var accessory by rememberSaveable(vm.accessory) { mutableStateOf(vm.accessory) }
    var expression by rememberSaveable(vm.expression) { mutableStateOf(vm.expression) }
    var relationship by rememberSaveable(vm.relationship) { mutableStateOf(vm.relationship) }
    var personality by rememberSaveable(vm.personality) { mutableStateOf(vm.personality) }
    var speechStyle by rememberSaveable(vm.speechStyle) { mutableStateOf(vm.speechStyle) }
    var formality by rememberSaveable(vm.formality) { mutableStateOf(vm.formality) }
    var affectionLevel by rememberSaveable(vm.affectionLevel) { mutableStateOf(vm.affectionLevel) }
    var memoryText by rememberSaveable { mutableStateOf("") }
    var profileName by rememberSaveable { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Avatar(face = "😊", hair = hair, eyes = eyes, style = style, skinTone = skinTone, hairstyle = hairstyle, outfit = outfit, accessory = accessory, expression = expression, modifier = Modifier.size(170.dp)) { }
            }
            Spacer(Modifier.height(8.dp))
            Text("استوديو توائمي", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("اضبط ملامح الشخصية وسلوكها وعلاقتها وطريقة الكلام. المعاينة البصرية في هذه النسخة رمزية، وليست نموذجاً واقعياً ثلاثي الأبعاد.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { OutlinedTextField(nickname, { nickname = it }, label = { Text("اسم الشخصية") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
        item { ChoiceRow("الأسلوب البصري", style, listOf("واقعي", "أنمي")) { style = it } }
        item { ChoiceRow("درجة البشرة", skinTone, listOf("فاتح", "قمحي", "زيتوني", "داكن")) { skinTone = it } }
        item { ChoiceRow("لون الشعر", hair, listOf("أسود", "بني", "أشقر", "أحمر", "فضي")) { hair = it } }
        item { ChoiceRow("تسريحة الشعر", hairstyle, listOf("قصير", "طويل", "مجعد", "مرفوع")) { hairstyle = it } }
        item { ChoiceRow("لون العينين", eyes, listOf("بني", "أزرق", "أخضر", "عسلي")) { eyes = it } }
        item { ChoiceRow("شكل الوجه", faceShape, listOf("بيضاوي", "دائري", "مربع", "ناعم")) { faceShape = it } }
        item { ChoiceRow("الطول", height, listOf("قصير", "متوسط", "طويل")) { height = it } }
        item { ChoiceRow("بنية الجسم", bodyShape, listOf("نحيف", "متوسط", "ممتلئ", "رياضي")) { bodyShape = it } }
        item { ChoiceRow("الملابس", outfit, listOf("يومي", "رسمي", "رياضي", "أنيق", "شتوي")) { outfit = it } }
        item { ChoiceRow("الإكسسوارات", accessory, listOf("لا شيء", "نظارات", "قبعة", "سماعات", "قلادة")) { accessory = it } }
        item { ChoiceRow("التعبير", expression, listOf("ودود", "فرح", "تفكير", "هادئ", "مرح")) { expression = it } }
        item { ChoiceRow("الصوت المفضّل على TTS", voice, listOf("هادئ", "مرح", "رسمي")) { voice = it } }
        item { ChoiceRow("نمط العلاقة", relationship, listOf("رفيق", "صديق", "شريك رقمي", "زوج/زوجة افتراضية")) { relationship = it } }
        item { ChoiceRow("الشخصية", personality, listOf("حنون", "مرح", "حكيم", "مشجع", "هادئ")) { personality = it } }
        item { ChoiceRow("أسلوب الحديث", speechStyle, listOf("طبيعي", "مختصر", "مفصل", "شاعري")) { speechStyle = it } }
        item { ChoiceRow("الرسمية", formality, listOf("عفوي", "متوازن", "رسمي")) { formality = it } }
        item { ChoiceRow("دفء التفاعل", affectionLevel, listOf("هادئ", "دافئ", "حنون")) { affectionLevel = it } }
        item {
            Button(onClick = {
                vm.saveStudio(nickname, style, hair, eyes, voice, skinTone, hairstyle, faceShape, bodyShape, height, outfit, accessory, expression, relationship, personality, speechStyle, formality, affectionLevel)
            }, modifier = Modifier.fillMaxWidth()) { Text("حفظ إعدادات الشخصية الحالية") }
            Divider(Modifier.padding(vertical = 8.dp))
            Text("الشخصيات المحفوظة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            OutlinedTextField(profileName, { profileName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("اسم نسخة الشخصية الجديدة") }, singleLine = true)
            OutlinedButton(onClick = { vm.saveStudio(nickname, style, hair, eyes, voice, skinTone, hairstyle, faceShape, bodyShape, height, outfit, accessory, expression, relationship, personality, speechStyle, formality, affectionLevel); vm.saveCurrentProfileAs(profileName); profileName = "" }, modifier = Modifier.fillMaxWidth()) { Text("حفظ كشخصية مستقلة") }
        }
        items(vm.avatarProfiles, key = { it.id }) { saved ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(saved.name, fontWeight = FontWeight.Bold)
                        Text("${saved.style} • ${saved.relationship} • ${saved.personality}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    OutlinedButton(onClick = { vm.applyAvatarProfile(saved.id) }) { Text("تطبيق") }
                    IconButton(onClick = { vm.deleteAvatarProfile(saved.id) }) { Icon(Icons.Default.Delete, contentDescription = "حذف الشخصية") }
                }
            }
        }
        item {
            Card {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("الذاكرة الشخصية", fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (vm.memoryEnabled) "الذاكرة مستخدمة في سياق الإجابات" else "استخدام الذاكرة معطّل", modifier = Modifier.weight(1f))
                        androidx.compose.material3.Switch(checked = vm.memoryEnabled, onCheckedChange = { vm.setMemoryEnabled(it) })
                    }
                    OutlinedTextField(value = memoryText, onValueChange = { memoryText = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("مثلاً: أفضل الإجابات العربية الواضحة...") })
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = { vm.addMemory(memoryText); memoryText = "" }, enabled = memoryText.isNotBlank()) { Text("حفظ في الذاكرة") }
                    vm.memories.forEach { mem ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("• ${mem.text}", modifier = Modifier.weight(1f))
                            IconButton(onClick = { vm.deleteMemory(mem.id) }) { Icon(Icons.Default.Delete, contentDescription = "حذف الذاكرة") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: TawaamiViewModel, pad: PaddingValues) {
    val context = LocalContext.current
    var baseUrl by rememberSaveable(vm.providerConfig.baseUrl) { mutableStateOf(vm.providerConfig.baseUrl) }
    var model by rememberSaveable(vm.providerConfig.model) { mutableStateOf(vm.providerConfig.model) }
    var apiKey by rememberSaveable { mutableStateOf("") }
    var showKey by rememberSaveable { mutableStateOf(false) }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            val result = runCatching {
                val output = context.contentResolver.openOutputStream(uri) ?: error("تعذر فتح ملف التصدير للكتابة.")
                output.bufferedWriter(Charsets.UTF_8).use { it.write(vm.exportDataJson()) }
            }
            vm.reportStatus(if (result.isSuccess) "تم تصدير نسخة بيانات توائمي إلى الملف الذي اخترته." else "فشل التصدير: ${result.exceptionOrNull()?.message ?: "خطأ كتابة"}")
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val result = runCatching {
                val input = context.contentResolver.openInputStream(uri) ?: error("تعذر فتح ملف الاستيراد للقراءة.")
                input.bufferedReader(Charsets.UTF_8).use { reader -> vm.importDataJson(reader.readText()) }
            }
            if (result.isFailure) vm.reportStatus("فشل الاستيراد: ${result.exceptionOrNull()?.message ?: "خطأ قراءة"}")
        }
    }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("الذكاء الاصطناعي", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("الربط متوافق مع واجهات OpenAI-compatible. عنوان الخدمة واسم النموذج قابلان للتغيير. لن يعمل الاتصال السحابي قبل إدخال مفتاح API صالح من مزودك.")
            OutlinedTextField(baseUrl, { baseUrl = it }, modifier = Modifier.fillMaxWidth(), label = { Text("عنوان API أو عنوان /v1") }, singleLine = true)
            OutlinedTextField(model, { model = it }, modifier = Modifier.fillMaxWidth(), label = { Text("اسم النموذج") }, singleLine = true)
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("مفتاح API (اتركه فارغاً للإبقاء على المفتاح الحالي)") },
                singleLine = true,
                visualTransformation = if (showKey) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                trailingIcon = { Text(if (showKey) "إخفاء" else "إظهار", modifier = Modifier.clickable { showKey = !showKey }.padding(8.dp)) }
            )
            Button(onClick = { vm.saveProvider(baseUrl, model, apiKey); apiKey = "" }, modifier = Modifier.fillMaxWidth()) { Text("حفظ إعدادات موفّر AI") }
            OutlinedButton(onClick = { vm.testProviderConnection() }, enabled = !vm.providerBusy, modifier = Modifier.fillMaxWidth()) { Text(if (vm.providerBusy) "جارٍ الاختبار…" else "اختبار الاتصال الفعلي") }
            OutlinedButton(onClick = { vm.removeApiKey() }, modifier = Modifier.fillMaxWidth()) { Text("حذف مفتاح API المحفوظ") }
            Text("حالة الاتصال: ${vm.providerStatus}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Divider()
            Text("البيانات والخصوصية", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("الوضع الداكن", fontWeight = FontWeight.SemiBold)
                    Text(if (vm.darkMode) "مفعّل" else "فاتح", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                androidx.compose.material3.Switch(checked = vm.darkMode, onCheckedChange = { vm.setDarkMode(it) })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("استخدام الذاكرة في الإجابات", fontWeight = FontWeight.SemiBold)
                    Text(if (vm.memoryEnabled) "مفعّل: يمكن استدعاء العناصر المحفوظة." else "معطّل: لا تُرسل عناصر الذاكرة إلى الموفّر.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                androidx.compose.material3.Switch(checked = vm.memoryEnabled, onCheckedChange = { vm.setMemoryEnabled(it) })
            }
            Text("المحادثة والذاكرة والمهام وإعدادات الشخصية تُحفظ محلياً. عند استخدام API سحابي، يُرسل سياق المحادثة والذاكرة المختارة ضمن الطلب إلى المزوّد الذي تختاره؛ راجع شروطه قبل إرسال معلومات حساسة.")
            OutlinedButton(onClick = { exportLauncher.launch("tawaami-export.json") }, modifier = Modifier.fillMaxWidth()) { Text("تصدير بيانات توائمي إلى JSON") }
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) { Text("استيراد نسخة JSON من توائمي") }
            OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) { Text("حذف البيانات المحلية ومفتاح API") }
        }
        item {
            Divider()
            Text("معلومات الإصدار", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Tawaami Android • 1.0.0 • Kotlin / Jetpack Compose")
            Text("الردود المحلية أساسية. الخدمات السحابية والرؤية تعتمد على الموفّر والنموذج وإعداداته. لا يتضمن التطبيق مفتاحاً سرياً افتراضياً.")
        }
    }
    if (confirmDelete) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("تأكيد حذف البيانات") },
            text = { Text("سيُحذف سجل المحادثة والذاكرة والمهام والإعدادات المحلية ومفتاح API المحفوظ من التطبيق. لا يمكن التراجع عن هذا الإجراء.") },
            confirmButton = { Button(onClick = { vm.deleteUserData(); confirmDelete = false }) { Text("حذف نهائياً") } },
            dismissButton = { OutlinedButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
        )
    }
}
