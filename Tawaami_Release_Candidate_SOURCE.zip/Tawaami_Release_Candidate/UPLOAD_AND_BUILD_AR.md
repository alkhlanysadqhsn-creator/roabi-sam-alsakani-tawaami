# ملاحظات البناء — Tawaami Android

هذه الصفحة تصف البناء، ولا تعني أن APK متوفر قبل نجاح الـ workflow. ناتج `Tawaami-debug-APK` يظهر فقط عند نجاح عملية التجميع.

## بيئة البناء
سير GitHub Actions يجهّز JDK 17 وAndroid SDK لمنصة Android 35 وأدوات البناء 35.0.0، ثم يثبت Gradle 8.7 ويشغّل `testDebugUnitTest assembleDebug`. يعتمد المشروع على AGP 8.6.1، الذي يدعم API 35 ويتطلب Gradle 8.7.

## إن ظهرت نتيجة بناء
في المستودع، افتح تبويب `Actions` ثم آخر تشغيل لـ `Build Tawaami Android APK`. إن كانت النتيجة ناجحة، نزّل `Tawaami-debug-APK` من قسم `Artifacts` داخل تشغيل العملية. إن كانت فاشلة، افتح السجل واقرأ أول خطأ Kotlin أو Gradle؛ لا تستنتج وجود APK من مجرد بدء العملية.

## ملاحظات المصدر
- ملفات Android الرئيسية في جذر المشروع: `settings.gradle.kts` و`build.gradle.kts` ومجلد `app/`.
- لا يوجد `gradle-wrapper.jar` حالياً؛ لهذا سير CI يستخدم Gradle المثبت من action بدلاً من `./gradlew`.
- `minSdk=30` يعني Android 11 فأحدث.
- لا يوجد مفتاح API ضمن الشيفرة. يضيف المستخدم مفتاح مزوّده بنفسه داخل إعدادات التطبيق، ويُخزّن مشفراً باستخدام Android Keystore.
- التحقق من بناء APK وتثبيته وتشغيل الوظائف الأساسية على هاتف Android ما زال مطلوباً قبل وصف نسخة بأنها متحققة نهائياً.
